inherit NPC;
inherit F_BANKER;

void create()
{
	set_name("������", ({"tie gongji", "tie", "gongji"}));
	set("title", "Ǯׯ�ϰ�");
	set("gender", "����");
	set("age", 34);
	set("str", 22);
	set("int", 24);
	set("dex", 18);
	set("con", 18);
	set("qi", 500);
    set("dealer", "bank");
       set("max_qi", 500);
	set("jing", 100);
	set("max_jing", 100);
	set("shen", 0);

	set("combat_exp", 50000);
	set("shen_type", 1);
	set("attitude", "friendly");
	set("env/wimpy", 50);
	set("chat_chance", 2);
	set("chat_msg", ({
	"����������һ����˵������Ǯׯ�Ǿ���������Ǯׯ��\n",
	}));
	set_skill("unarmed", 50);
	set_skill("dodge", 50);
	set_temp("apply/attack", 100);
	set_temp("apply/defense", 100);
	set_temp("apply/damage", 40);

	setup();
	 carry_object("/d/beijing/npc/obj/cloth")->wear();
	add_money("silver", 30);
}

void init()
{
	add_action("do_check", "check");
	add_action("do_convert", "duihuan");
	add_action("do_deposit", "cun");
	add_action("do_withdraw", "qu");
	delete_temp("busy");
}
