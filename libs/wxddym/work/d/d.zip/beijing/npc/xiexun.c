// XieXun.c
// pal 1997.05.09

#include <ansi.h>


inherit NPC;
inherit F_UNIQUE;

mixed ask_cheng();
string xunlian() ;

void create()
{
        set_name("лѷ", ({"xie xun", "xie", "xun", }));
        set("long",
        "����һλ���Ŀ�ΰ�쳣�ĵ����ߣ�����һ���ײ����ۡ�\n"
        "����ͷ�Ʒ����������ݣ���������һ�㣬ֻ����ֻ�۾�����������\n"
        );

        set("title",HIG "����" HIY "��ëʨ��" NOR);
        set("level",9);
        set("gender", "����");
        set("attitude", "peaceful");

        set("age", 63);
        set("shen_type", 1);
        set("per", 20);
        set("str", 30);
        set("int", 30);
        set("con", 30);
        set("dex", 30);

        set("max_qi", 350000);
        set("max_jing", 1500);
        set("neili", 3000);
        set("max_neili", 3000);
        set("jiali", 150);

        set("combat_exp", 9000000000);
        set("score", 800000);

	set_skill("force", 1800);
	set_skill("dodge", 1800);
	set_skill("parry", 1800);
	set_skill("sword", 1800);
	set_skill("cuff", 1800);
	set_skill("strike", 1800);
	set_skill("finger",2000);
	set_skill("literate", 1100);

	set_skill("shenghuo-xinfa", 1800);
	set_skill("lingxu-bu", 1800);
	set_skill("shenghuo-quan", 1800);
	set_skill("guangming-zhang", 1800);
	set_skill("liehuo-jian", 1800);
	set_skill("huanyin-zhi", 2000);
	set_skill("qishang-quan",2000);

	map_skill("force", "shenghuo-xinfa");
	map_skill("dodge", "lingxu-bu");
	map_skill("strike", "guangming-zhang");
	map_skill("sword", "liehuo-jian");
	map_skill("parry", "qishang-quan");
	map_skill("cuff", "qishang-quan");
	map_skill("finger","huanyin-zhi");

	prepare_skill("cuff", "qishang-quan");

        set("chat_chance_combat", 200);
        set("chat_msg_combat", ({
                (: command("perform cuff.qimai") :),
        }) );
        create_family("����", 35, "��������");
        set("inherit_title",HIG"����"NOR"����ɢ��"NOR);
        set("inquiry", ([
                "����" : (: do_training :),
        ]));
        set("master_ob",3);
	setup();
        //carry_object("/d/mingjiao/obj/baipao")->wear();
         carry_object("/clone/weapon/dragonblade")->wield();  
}
int do_training(string arg)
{
	object me= this_player();

	if(me->query_temp("weapon") != this_object()) return 0;

	return "/adm/daemons/makeweapon"->call_do_training(me,arg);
}