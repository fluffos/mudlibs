
#include <ansi.h>

inherit ITEM;

void create()
{
        set_name(HIY "������������" NOR, ({ "bao1" }) );
        set_weight(1);
        if( clonep() )
                set_default_object(__FILE__);
        else {
		set("long","����95%ʧ�ܵ�"+this_object()->query("name")+",\n"ZJURL("cmds:open bao1")ZJSIZE(15)"��"NOR"����!\n");
                set("xy_money", 888);
                set("unit", "��");                
        }
        setup();
}

void init()
{
        add_action("do_open", "open");
}

int do_open(string arg)
{

        object me, ob;
        int exp, qn;
        string sob, msg;
        string *gifts =({
               "/clone/xinnian/wenshen/tattoo3",
               "/clone/xinnian/wenshen/tattoo4",
               "/clone/xinnian/wenshen/tattoo5",
               "/clone/xinnian/wenshen/tattoo6",
               "/clone/xinnian/wenshen/tattoo7",
               "/clone/xinnian/wenshen/tattoo8",
                                                  
        });

        me = this_player();

        if (environment(this_object()) != me)return 0;

        if (random(100) < 95)
        {                
                write("��򿪰���һ�������澡��һЩ��ֵǮ�Ķ��������ֽ�֮����һ�ߡ�\n");
                destruct(this_object());
                return 1;
        }

        // ��ȡһЩ����
        exp = 0;
        qn = 0;

        sob = gifts[random(sizeof(gifts))];

        ob = new(sob);

        if (objectp(ob))
        {
                msg = HIR "\n������ " + chinese_number(exp) + " ��ʵս���鼰 " + chinese_number(qn) + " ��Ǳ�ܡ�\n" NOR;
                msg += HIY "���" + this_object()->name() + HIY "�ѳ�" + ob->name() + HIY "��\n\n" NOR;
                tell_object(me, msg);
                ob->move(me, 1);
                me->add("combat_exp", exp);
                me->add("potential", qn);
        }
        else
        {
                write("���" + sob + " ����\n");
        }

        destruct(this_object());
        return 1;
}

