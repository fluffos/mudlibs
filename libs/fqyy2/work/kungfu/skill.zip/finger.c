// finger.c

inherit SKILL;
