// cuff.c

inherit SKILL;
