// club.c

inherit SKILL;
