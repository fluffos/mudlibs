// hand.c

inherit SKILL;
