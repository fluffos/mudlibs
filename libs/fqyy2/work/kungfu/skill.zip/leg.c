// staff.c

inherit SKILL;
