// staff.c

inherit SKILL;
