// lingfa.c

inherit SKILL;
