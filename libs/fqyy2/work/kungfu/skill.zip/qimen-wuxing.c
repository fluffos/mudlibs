// qimen-wuxing

inherit SKILL;

void create() { seteuid(getuid()); }

int valid_enable(string usage)
{
return (usage=="array");
}

int practice_skill(object me)
{	
	return notify_fail("���������ܿ�ѧ(learn)����ߡ�\n");
}
string perform_action_file(string action)
{return __DIR__+"qimen-wuxing/"+action;
}