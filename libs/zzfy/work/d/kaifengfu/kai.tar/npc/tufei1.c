// add by atu for LSFY 2000/01/10
#include <ansi.h>
inherit NPC;

int ask_me();

void create()
{
        set_name("��������", ({ "picture"}) );
        set("gender", "����" );
        set("age", 34);
        set("long",
                "�������׺ݵ�����������������������ڡ�\n");
        set("max_kee", 5000);
        set("max_gin", 5000);
        set("max_force", 5000);
        set("force_factor", 500);
        set("combat_exp", 4000000);
        set("attitude", "friendly");
        set("title", "");
       set("str", 30);
       set("dex", 20);
       set("con", 20);
       set("int", 20);
        set_skill("dodge", 500);
        set_skill("unarmed",500);
        set_skill("parry", 500);
        set_skill("force",500);
        set_skill("literate", 500);
        set_skill("wuzheng-force", 500);
        set_skill("bat-blade", 500);
        set_skill("blade", 500);
        set_skill("meng-steps", 500);
               
       set("no_see", 1);
       set_weight(5);
       map_skill("force", "wuzheng-force");
       map_skill("dodge", "meng-steps");
       map_skill("blade", "bat-blade");
       map_skill("parry", "bat-blade");
       set("chat_chance_combat", 10);
       set("chat_msg_combat", ({
                (: perform_action, "blade.shiwanshenmo" :),
                (: perform_action, "dodge.huanyingqianchong" :),
        }) );
        setup();
}


void init()
{       
        object ob,obj;
       int maxskill;
//      ::init();
        if( interactive(ob = this_player()) && !this_object()->query_temp("kf_inited")) {
       this_object()->set_temp("kf_inited",1);
       obj=this_object();
       maxskill=query("maxskill");
        set_skill("dodge", maxskill);
        set_skill("force", maxskill);
        set_skill("unarmed", maxskill);
        set_skill("parry", maxskill);
        set_skill("blade", maxskill);
//        set_skill("claw", maxskill);
        set_skill("bat-blade", maxskill);
//        set_skill("jiuyin-baiguzhao", maxskill*2/3);
        set_skill("meng-steps", maxskill);
        set_skill("wuzheng-force", maxskill);
        carry_object("/obj/weapon/blade")->wield();
       obj->set("title","ɱ������");
       obj->set_weight(500000);
        set_name("������", ({ "mengmian dadao","md"}) );
        remove_call_out ("destroy_npc");
        call_out ("destroy_npc", 900); // 15 min
        }
}
void destroy_npc()
{
        message_vision("" + (string)this_object()->query("name") + "��Ȼ���˸����£������������⣬����һ�Σ���ʱ����çç�˺�֮�С�\n", environment(this_object()));
        destruct(this_object());
}
// int active_died()
void die()
{
        object ob,me;
        string own;
    message_vision("$N���ڵ��ϣ����ˣ�\n", this_object());
    ob = this_object();
    own = ob->query_temp("kf_ownname");
    if(own) me = find_player(own);
    if ( me && ob->query_temp("last_damage_from")==me){
        if (ob->query_temp("kf_npc")==me->query_temp("kf_npc"))
               me->set_temp("kf_finish",1);
     }
        destruct(this_object());
}

