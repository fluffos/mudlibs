#include "./language.h"

void create()
{
}

string parseLanguage(string str, mixed* obs)
{
  string *parts;
  int i, j;
  int obc;
  int gender;
  int casus;
  int plural;
  int cap;
  int article;

  obc = 0;
  parts = explode(str, "$");
  if (str[0..0] == "$") // Startpunkt bestimmen
    i = 0;
  else
    i = 1;
  for (i, j = sizeof(parts); i < j; i += 2) {
    cap = 0;
    casus = to_int(parts[i][1..1]) - 1;
    switch (parts[i][0..0]) {
      case "G":
        cap = 1;
      case "g":
        parts[i] = LANGUAGEMASTER->getGenderString(obs[obc]);
        break;

      case "N":
        cap = 1;
      case "n":
        if (strlen(parts[i]) >= 3)
          article = to_int(parts[i][2..2]);
        else
          article = 0;
        if (strlen(parts[i]) >= 4)
          plural = to_int(parts[i][3..3]);
        else
          plural = 0;
        if (objectp(obs[obc]))
          parts[i] = obs[obc]->getVisibleName(casus, article, plural);
        else if (pointerp(obs[obc]))
          parts[i] = obs[obc][casus][plural];
        break;

      case "P": // Pronomen
        cap = 1;
      case "p":
        if (objectp(obs[obc]))
          gender = obs[obc]->getGender();
        else
          gender = obs[obc];
        parts[i] = LANGUAGEMASTER->getPronoun(gender, casus);
        break;

      case "Q": // PossesivPronomen
        cap = 1;
      case "q":
        if (objectp(obs[obc])) {
          gender = obs[obc]->getGender();
          plural = obs[obc]->getPlural();
        }
        else if (intp(obs[obc])) {
          gender = obs[obc];
          plural = 0;
        }
        else if (pointerp(obs[obc]) && sizeof(obs[obc]) >= 2) {
          gender = obs[obc][0];
          plural = obs[obc][1];
        }
        obc++;
        parts[i] = LANGUAGEMASTER->getPossPronoun(obs[obc], gender, casus, plural);
        break;

      case "V": // Verb, fast wie array, nur reihenfolge im array ist anders
        cap = 1;
      case "v":
        if (pointerp(obs[obc]) && intp(obs[obc + 1])) {
          casus = obs[obc + 1] - 3;
          if (casus < 0)
            casus = 2;
          parts[i] = obs[obc][casus];
        }
        obc++;
        break;

      case "X": // Aus Array auswaehlen
        cap = 1;
      case "x":
        if (pointerp(obs[obc]) && intp(obs[obc + 1]))
          parts[i] = obs[obc][obs[obc + 1]];
        obc++;
        break;
    }
    if (cap)
      parts[i] = capitalize(parts[i]);
    obc++;
  }
  return implode(parts, "");
}

