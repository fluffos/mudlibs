
inherit "/std/thing";

#include "../def.h"

int gesperrt = 1;

void create()
{
  if (!is_clone(this_object()))
    return;
  ::create();
  SetProp(P_SHORT,0);
  SetProp(P_WEIGHT,0);
  SetProp(P_VALUE,0);
  SetProp(P_INVIS,1);
  SetProp(P_NODROP,1);
  SetProp(P_NOSELL,1);
  SetProp(P_NOBUY,1);
  SetProp(P_NEVERDROP,1);
  SetProp(P_AUTOLOADOBJ,1);
  SetProp(P_GENDER, FEMALE);
  SetProp(P_NAME,"Sperre");
  AddId( ({"\nruf_sperre"}) );

  AddCmd( ({"ruf", "rufe"}), "cmd_rufen");
  AddCmd( ({"-"}), "cmd_rufen", 1);
  AddCmd( ({"luna"}), "cmd_entsperren");
  AddCmd( ({"anul"}), "cmd_sperren");
}

int cmd_entsperren(string str)
{
  gesperrt = 0;
  return 1;
}

int cmd_sperren(string str)
{
  gesperrt = 1;
  return 1;
}

int cmd_rufen(string str)
{
  if (gesperrt)
    return 1;
  else
    return 0;
}

void BecomesNetDead(object spieler)
{
  gesperrt = 1;
}

