#include "./language.h"

void create()
{
  seteuid(getuid(this_object()));
}

/*
 *  0.. kein Artikel
 *  1.. immer ein Artikel
 */
int article = 1;

void setHasArticle(int art)
{
  article = art;
}

int hasArticle()
{
  return article;
}

/*
 *  0..saechlich (NEUTER)
 *  1..maennlich (MALE)
 *  2..weiblich (FEMALE)
 */
int gender = NEUTER;

void setGender(int g)
{
  gender = g;
}

int getGender()
{
  return gender;
}

/*
 * string                     normaler Name, wird regulaer dekliniert
 * ({string, ADJECTIVE})      substantivisch gebrauchtes Adjektiv
 *                            zb fuer der Untote, der Wilde usw...
 * ({wer, wessen, wem, wen})  array mit den 4 unregelmaessigen Faellen.  
 */
mixed name = "Etwas";

void setName(mixed n)
{
  name = n;
}

mixed getName()
{
  if (pointerp(name))
    return name[0];
  else
    return name;
}

/*
 * string, beinhaltet den nicht zu deklinieren Teil des Namen, 
 * zb "der Vernichtung" beim "Schwert der Vernichtung"
 * ein fehlendes Leerzeichen am Anfang wird automatisch dazugefuegt
 */
string suffix = "";

void setSuffix(string suf)
{
  if (suf[0..0] != " " && suf[0..0] != ",")
    suf = " " + suf;
  suffix = suf;
}

string getSuffix()
{
  return suffix;
}

/*
 * string, beinhaltet den nicht zu deklinieren Teil vor dem Namen, 
 * zb ein Titel wie "Baron" oder sowas
 * wird wohl nur beim Spielern verwendung finden, weil man dort
 * ja den Namen nicht wird veraendern koennen
 * ein fehlendes Leerzeichen am Ende wird automatisch dazugefuegt
 */
string prefix = "";

void setPrefix(string pref)
{
  if (pref[strlen(pref)..strlen(pref)] != " ")
    pref = pref + " ";
  prefix = pref;
}

string getPrefix()
{
  return prefix;
}

/*
 * boolean, gesetzt, wenn es sich um ein Pluralobjekt handelt
 */
int plural = 0;

void setPlural(int p)
{
  plural = p;
}

int isPlural()
{
  return plural;
}

/*
 * - string                    Ist die Pluralform zu setName()
 * - ({string, ADJECTIVE})     substantivisch gebrauchtes Adjektiv
 *                             zb fuer die Untoten, die Wilden usw...
 * - ({wer, wessen, wem, wen}) array mit den 4 unregelmaessigen
 *                             Faellen im Plural.
 */
mixed pluralname;

void setPluralName(mixed n)
{
  pluralname = n;
}

mixed getPluralName()
{
  return pluralname;
}

/*
 * string .. Adjektiv ohne Deklination, zb "gross", "schwer"
 */ 
string* adjective = ({});

void addAdjective(string adj)
{
  adjective += ({adj});
}
/*
 * TODO: deklinierte formen der Adjektive zu den IDS hinzufuegen, damit
 * zb "nimm grosse keule" und "steck kleines messer in grossen beutel" geht.       
 */

/*
 * string* .. liste von Adjektiven, wie oben
 */
void addAllAdjective(string* adj)
{
  adjective += adj;
}

string* getAdjective()
{
  return adjective;
}

void removeAdjective(mixed adj)
{
  if (pointerp(adjective)) {
    if (pointerp(adj))
      adjective -= adj;
    else if (stringp(adj))
      adjective -= ({adj});
  }
}

void removeAllAdjective()
{
  adjective = ({});
}

/*
 * Zur Performance-Steigerung werden die Namen einmal am Anfang in allen
 * moeglichen Faellen erzeugt.
 */
mixed nameArray;

void declinateNames()
{
  nameArray = allocate(2);
  nameArray[0] = allocate(8 + (hasArticle() ? 4 : 0));
  nameArray[1] = allocate(8);
  nameArray[0][0] = LANGUAGEMASTER->declinateName(this_object(), WER, UNBESTIMMTER_ARTIKEL, SINGULAR);
  nameArray[0][1] = LANGUAGEMASTER->declinateName(this_object(), WESSEN, UNBESTIMMTER_ARTIKEL, SINGULAR);
  nameArray[0][2] = LANGUAGEMASTER->declinateName(this_object(), WEM, UNBESTIMMTER_ARTIKEL, SINGULAR);
  nameArray[0][3] = LANGUAGEMASTER->declinateName(this_object(), WEN, UNBESTIMMTER_ARTIKEL, SINGULAR);

  nameArray[0][4] = LANGUAGEMASTER->declinateName(this_object(), WER, BESTIMMTER_ARTIKEL, SINGULAR);
  nameArray[0][5] = LANGUAGEMASTER->declinateName(this_object(), WESSEN, BESTIMMTER_ARTIKEL, SINGULAR);
  nameArray[0][6] = LANGUAGEMASTER->declinateName(this_object(), WEM, BESTIMMTER_ARTIKEL, SINGULAR);
  nameArray[0][7] = LANGUAGEMASTER->declinateName(this_object(), WEN, BESTIMMTER_ARTIKEL, SINGULAR);

  if (hasArticle())
  {
    nameArray[0][8] = LANGUAGEMASTER->declinateName(this_object(), WER, KEIN_ARTIKEL, SINGULAR);
    nameArray[0][9] = LANGUAGEMASTER->declinateName(this_object(), WESSEN, KEIN_ARTIKEL, SINGULAR);
    nameArray[0][10] = LANGUAGEMASTER->declinateName(this_object(), WEM, KEIN_ARTIKEL, SINGULAR);
    nameArray[0][11] = LANGUAGEMASTER->declinateName(this_object(), WEN, KEIN_ARTIKEL, SINGULAR);
  }
  nameArray[1][0] = LANGUAGEMASTER->declinateName(this_object(), WER, UNBESTIMMTER_ARTIKEL, PLURAL);
  nameArray[1][1] = LANGUAGEMASTER->declinateName(this_object(), WESSEN, UNBESTIMMTER_ARTIKEL, PLURAL);
  nameArray[1][2] = LANGUAGEMASTER->declinateName(this_object(), WEM, UNBESTIMMTER_ARTIKEL, PLURAL);
  nameArray[1][3] = LANGUAGEMASTER->declinateName(this_object(), WEN, UNBESTIMMTER_ARTIKEL, PLURAL);

  nameArray[1][4] = LANGUAGEMASTER->declinateName(this_object(), WER, BESTIMMTER_ARTIKEL, PLURAL);
  nameArray[1][5] = LANGUAGEMASTER->declinateName(this_object(), WESSEN, BESTIMMTER_ARTIKEL, PLURAL);
  nameArray[1][6] = LANGUAGEMASTER->declinateName(this_object(), WEM, BESTIMMTER_ARTIKEL, PLURAL);
  nameArray[1][7] = LANGUAGEMASTER->declinateName(this_object(), WEN, BESTIMMTER_ARTIKEL, PLURAL);

  printf("%O\n", nameArray);
}

/*
 *  Diese Funktiongibt den Namen im richtigen Fall zurueck.
 */
string getVisibleName(int casus, int demon, int plural)
{
  return nameArray[plural % 2][(casus + demon * 4) % sizeof(nameArray[0])];
}


