#define NEUTER 0
#define NEUTRUM 0
#define MALE 1
#define FEMALE 2
#define RAW 99

#define ICH 3
#define DU 4
#define WIR 6
#define IHR 7
#define SIE 8

#define WER 0
#define WESSEN 1
#define WEM 2
#define WEN 3

#define NOMINATIV 0
#define GENETIV 1
#define DATIV 2
#define AKKUSATIV 3

#define UNBESTIMMTER_ARTIKEL 0
#define BESTIMMTER_ARTIKEL 1
#define KEIN_ARTIKEL 2

#define ADJECTIVE "ADJECTIVE"
#define SINGULAR 0
#define PLURAL 1

#define LANGUAGEMASTER "/players/feyaria/secure/language_master"
