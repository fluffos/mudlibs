#define NEUTER 0
#define NEUTRUM 0
#define MALE 1
#define FEMALE 2

#define ICH 3
#define DU 4
#define WIR 6
#define IHR 7
#define SIE 8

#define WER 0
#define WESSEN 1
#define WEM 2
#define WEN 3

void create()
{
}

private varargs string query_c_article(int gender, int casus, int plural)
{
  if (plural)
    return ({ "die ", "der ", "den ", "die "})[casus];
  return ({ ({ "das ", "des ", "dem ", "das " }),
            ({ "der ", "des ", "dem ", "den " }),
            ({ "die ", "der ", "der ", "die " }) }) [gender % 3][casus];
}

private varargs string query_g_suffix(int gender, int casus, int plural)
{
  return ({ ({ ({"","e"}), ({"es","er"}), ({"em","en"}), ({"","e"}) }),
	    ({ ({"","e"}), ({"es","er"}), ({"em","en"}), ({"en","e"}) }),
	    ({ ({"e","e"}), ({"er","er"}), ({"er","en"}), ({"e","e"}) }) })
    [gender][casus][plural];
}

private string query_ic_article(int gender, int casus, int plural)
{
  if (plural) return "";
  return "ein"+query_g_suffix( gender % 3, casus )+" ";
}

varargs string declinateArticle(int gender, int casus, int demon, int plural)
{
  if (demon) return query_c_article(gender, casus, plural);
  return query_ic_article(gender, casus, plural);
}

varargs string getPossPronoun(mixed from, int gender, int casus, int plural)
{
  int fromGender;
  int fromPlural;

  if (intp(from)) {
    fromGender = from;
    fromPlural = 0;
  } 
  else if (pointerp(from)) {
    fromGender = from[0];
    fromPlural = from[1];
  }
  else {
    fromGender = from->getGender();
    fromPlural = from->getPlural();
  }
  return ({"sein", "sein", "ihr", "mein", "dein", "unser", "euer", "ihr"}) [gender % 8] + 
    query_g_suffix(fromGender, casus, plural);
}

varargs string getPronoun(int gender, int casus)
{
  return ({ ({"es", "seiner", "ihm", "es"}),
            ({"er", "seiner", "ihm", "ihn"}),
            ({"sie", "ihrer", "ihr", "sie"}), 
            ({"ich", "meiner", "mir", "mich"}),
            ({"du", "deiner", "dir", "dich"}),
            ({"wir", "unser", "uns", "uns"}),
            ({"ihr", "euer", "euch", "euch"}),
            ({"sie", "ihr", "ihnen", "sie"}), }) [gender % 8][casus % 4];
}

string getGenderString(int gender)
{
  switch (gender % 3)
  {
    case MALE  : return "maennlich";
    case FEMALE: return "weiblich";
    case NEUTER: return "saechlich";
  }
}

varargs string declinateAdjective(string adj, int gender, int casus, int demon, int plural)
{
  if (!adj) return "";

  if (plural) {
    if (demon) return adj + "en ";
    return adj + ({ "e", "er", "en", "e" }) [casus] + " ";
  }
  if(demon)
    return adj + ({ ({ "e" , "en", "en", "e"  }),
		    ({ "e" , "en", "en", "en" }),
		    ({ "e" , "en", "en", "e"  }) })
      [gender % 3][casus] + " ";
  else
    return adj + ({ ({ "es", "en", "en", "es" }),
		    ({ "er", "en", "en", "en" }),
		    ({ "e" , "en", "en", "e"  }) })
      [gender % 3][casus] + " ";
}


string* declinateName(string n, int gender, int article)
{
  int casus;
  string last;
  string *ret;

  ret = ({n, n, n, n});
  last = n[<1];
  for (casus = WESSEN; casus <= WEN; casus++) {
    switch (casus) {
      case WEM:
      case WEN:
        if (article && gender == MALE && last == 'e')
          ret[casus] = n + "n";
        break;
      case WESSEN:
        if (!article) {
          switch(last) {
            case 'x':
            case 's':
            case 'z': ret[WESSEN] = n + "'";
                      break;
            default:  ret[WESSEN] = n + "s";
          }
        }
        else {
          switch (gender) {
            case MALE:
              switch (last) {
                case 'x':
                case 's':
                case 'z': break;
                case 'e': ret[WESSEN] = n + "n";
                          break;
                default:  ret[WESSEN] = n + "s";
              }
              break;
            case NEUTER:
              switch (last) {
                case 'x':
                case 's':
                case 'z': break;
                default:  ret[WESSEN] = n + "s";
              }
              break;
            case FEMALE:
              break;
          } 
        }
    }
  }
  return ret;
}


//--------------------------------------------------------------------------

string* name;

void setName(mixed n)
{
  if (stringp(n))  // Normaler Name, wird mit Standard-regeln dekliniert
    name = declinateName(n);
  else if (!pointerp(n))
    return;
  else
  {
    if (sizeof(n) == 4 || sizeof(n) == 8)  // Alle vier oder acht Faelle im Array angegeben
      name = n;
    else  // Adjektivisch gebrauchtes Sustantiv, gender muss hier schon gesetzt sein!!
    {
      if (n[0][<1] == 'e') 
        n = n[0][0..<2];
      else 
        n = n[0][0..<3];
      name = ({
          declinateAdjective(n, getGender(), WER, 0),
          declinateAdjective(n, getGender(), WESSEN, 0),
          declinateAdjective(n, getGender(), WEM, 0),
          declinateAdjective(n, getGender(), WEN, 0),
          declinateAdjective(n, getGender(), WER, 1),
          declinateAdjective(n, getGender(), WESSEN, 1),
          declinateAdjective(n, getGender(), WEM, 1),
          declinateAdjective(n, getGender(), WEN, 1),
          });
    }
  }
}

varargs string getName(int casus, int demon)
{
  return name[(casus + 4 * demon) % sizeof(name)];
}


string* pluralname;

void setPluralname(mixed n)
{
}

