#include "./language.h"

void create()
{
}

/*
 *  Suffix fuer unbestimmten Artikel und Adjektive
 *  gender ... NEUTER, MALE, FEMALE
 *  casus  ... WER, WESSEN, WEM, WEN
 *  plural ... true oder false
 */ 
private varargs string getDeclinationSuffix(int gender, int casus, int plural)
{
  return ({ ({ ({"","e"}), ({"es","er"}), ({"em","en"}), ({"","e"}) }),
	    ({ ({"","e"}), ({"es","er"}), ({"em","en"}), ({"en","e"}) }),
	    ({ ({"e","e"}), ({"er","er"}), ({"er","en"}), ({"e","e"}) }) })
    [gender % 3][casus % 4][plural % 2];
}

/*
 *  bestimmter Artikel in allen moeglichen faellen und geschlechtern
 */ 
private varargs string getDefiniteArticle(int gender, int casus, int plural)
{
  if (plural)
    return ({ "die ", "der ", "den ", "die "}) [casus % 4];
  return ({ ({ "das ", "des ", "dem ", "das " }),
            ({ "der ", "des ", "dem ", "den " }),
            ({ "die ", "der ", "der ", "die " }) }) [gender % 3][casus % 4];
}

/*
 *  unbestimmter Artikel in allen moeglichen faellen und geschlechtern
 */ 
private string getIndefiniteArticle(int gender, int casus, int plural)
{
  if (plural) return "";
  return "ein" + getDeclinationSuffix(gender, casus) + " ";
}

/*
 * demon:  0 ... unbestimmter Artikel
 *         1 ... bestimmter Artikel 
 */
varargs string declinateArticle(int gender, int casus, int demon, int plural)
{
  if (demon) return getDefiniteArticle(gender, casus, plural);
  return getIndefiniteArticle(gender, casus, plural);
}

/*
 *  adj           Adjektiv, das dekliniert werden soll
 *  casus         Fall 0 bis 3 (WER, WESSEN, WEM, WEN)
 *  demon         unbestimmert oder bestimmter Artikel (0 oder 1)
 *  plural        Singular oder Plural (0 bzw 1)
 */
varargs string declinateAdjective(string adj, int gender, int casus, int demon, int plural)
{
  if (!adj || !stringp(adj)) return "";

  if (plural) {
    if (demon) return adj + "en ";
    return adj + ({ "e", "er", "en", "e" }) [casus] + " ";
  }
  if(demon)
    return adj + ({ ({ "e" , "en", "en", "e"  }),
		    ({ "e" , "en", "en", "en" }),
		    ({ "e" , "en", "en", "e"  }) })
      [gender % 3][casus] + " ";
  else
    return adj + ({ ({ "es", "en", "en", "es" }),
		    ({ "er", "en", "en", "en" }),
		    ({ "e" , "en", "en", "e"  }) })
      [gender % 3][casus] + " ";
}
/*
 * TODO: auf unregelmaessige Adjetive abfragen und diese behandlen, zb "rosa"
 *       oder man umgeht das mittels "rosarot" :)
 */

/*
 *  gibt den Namen im richtigen Fall zurueck, samt Artikel und Adjectiven
 *  casus: die 4 Faelle WER, WESSEN, WEM, WEN, bzw RAW
 *         0, WER, NOMINATIV    erster Fall
 *         1, WESSEN, GENETIV   zweiter Fall
 *         2, WEM, DATIV        dritter Fall
 *         3, WEN, AKKUSATIV    vierter Fall
 *         99, RAW              gibt den Namen ohne Artikel, Adjektive und Suffix aus
 *
 *  demon: 0           unbestimmter Artikel
 *         1           bestimmter ARtikel
 *         99 (RAW)    ohne Artikel, aber dekliniert mit Suffix, wird verwendet
 *                     wenn man statt dem Artikel ein Possesivpronomen will.
 *                     Beispiel: "Du schaust in deinen Beutel des Reisenden"
 *
 *  amount: 0          Singular
 *          1          Plural
 *          >1         Anzahl der Gegenstaende, zb 3 Langschwerter
 */
varargs string declinateName(object ob, int casus, int demon, int amount)
{
  string adj; // fuer Adjektive
  mixed n;  // fuer Namen
  mixed pn;  // fuer Pluralnamen
  mixed last; // letzer Bcuhstabe des Namens
  int art;  // flag fuer Artikel
  int adject; // flag fuer adjektivisch gebrauchtes Sustantiv
  int g; // Geschlecht

  // Kein Name gesetzt, ergibt einen leerstring um bugs zu vermeiden
  if (!(n = ob->GetName())) 
    return "";
  g = ob->GetGender();

  if (!intp(casus))
    casus = RAW;
  if (casus == RAW) {
    if (pointerp(n))
      return n[WER];
    return n;
  }

  art = ob->hasArticle();
  if (!art || !demon || !intp(demon))
    demon = 0;
 
  // Pluralbehandlung
  if (amount || ob->GetPlural()) {
    if (stringp(pn = ob->GetPluralName()))  // Pluralname angegeben
      n = pn;
    else if (pointerp(pn)) {  // Behandlung unregelmaessiger Pluralnamen
      n = pn;
      if (sizeof(n) >= 2 && n[1] == ADJECTIVE) { // Entweder wie ein Adjectiv deklinieren
        n = n[0]; 
        adject = 1; 
      }
      else if (sizeof(n) > casus) // oder es sind die 4 Faelle direkt angegeben
        n = n[casus];
      else 
        n = n[0];  // Wenn zuwenig Faelle angegeben sind, muss der Nominativ herhalten
    }
    else {
      if (pointerp(n)) { // Unregelmaessiges Singularsubstaniv
        if (sizeof(n) >= 2 && n[1] == ADJECTIVE) // als Adjective deklinieren
          adject = 1;
        n = n[0];
      }
      if (!pn) {       // Nur, wenns kein Pluralobjekt ist:
        //   Trivial-grammatik anwenden (eher selten korrekt, aber besser als gar nichts
        if (n[<1] == 'l')
          if (g == FEMALE)
            n += "n";
          else
            ;
        else if (n[<1] == 'e')
          n += "n";
        else
          n += "e";
      }
    }
    last = n[<1];
    if (adject) {
      if (last == 'e') 
        n = n[0..<2]; // zB der Untote -> adjektiv ist "untot", letzer Buchstabe weg
      else 
        n = n[0..<3]; // zb ein Wilder -> adjektiv ist "wild", 2 Buchstaben hinten weg
      n = declinateAdjective(n, g, casus, demon, PLURAL);
      n = n[0..<2]; // Leerzeichen hinten entfernen
    }
    else if (last != 's' && last != 'n' && casus == WEM) 
      n = n + "n";
    if (pointerp(last = ob->getAdjective()))  // alle adjektive deklinieren
      adj = implode(map_array(last, #'declinateAdjective, g, casus, demon, PLURAL), "");
    if (!stringp(adj)) 
      adj = "";
    if (plural > 1) // In Plural war die Anzahl der Objekte angeben
      return declinateArticle(g, casus, demon, PLURAL) + 
        to_string(plural) + " " + adj + n + ob->getSuffix();
    else 
      return declinateArticle(g, casus, demon, PLURAL) + adj + n + ob->getSuffix();
  }
  // Ende Plural

  if (pointerp(n)) {
    if (sizeof(n) < 2) return 0;
    if (n[1] == ADJECTIVE) {
      if (n[0][<1] == 'e')
        n = n[0][0..<2]; // zB der Untote -> adjektiv ist "untot", letzer Buchstabe weg
      else
        n = n[0][0..<3]; // zb ein Wilder -> adjektiv ist "wild", 2 Buchstaben hinten weg
      n = declinateAdjective(n, g, casus, demon);
      n = n[0..<2]; // Leerzeichen hinten entfernen
    }
    else if (sizeof(n) > casus) // es sind die 4 Faelle direkt angegeben
      n = n[casus];
    else 
      n = n[0]; // Wenn zuwenig Faelle angegeben sind, muss der Nominativ herhalten
  }
  else if (stringp(n)) 
  {
    last = n[<1];
    switch (casus) {
      case WEM:
      case WEN:
        if (art && g == MALE && last == 'e')
          n = (string) n + "n";
        break;
      case WESSEN:
        if (!art) { // Genetiv ist unterschiedlich, abhaengig von artikel oder kein artikel
          switch (last) {
            case 'x':
            case 's':
            case 'z': n= (string) n + "'";
                      break;
            default:  n= (string) n + "s";
          }
        }
        else {
          switch (g) {
            case MALE:
              switch (last) {
                case 'x':
                case 's':
                case 'z': break;
                case 'e': n = (string) n + "n";
                          break;
                default:  n = (string) n + "s";
              }
              break;
            case NEUTER:
              switch (last) {
                case 'x':
                case 's':
                case 'z': break;
                default:  n = (string) n + "s";
              }
              break;
            case FEMALE:
              break;
          }
        }
    }
  }
  if (demon == RAW)
    return (string) n + ob->getSuffix();
  if (pointerp(last = ob->getAdjective())) // alle Adjektive deklinieren
    adj = implode(map_array(last, #'declinateAdjective, g, casus, demon), "");
  if (!stringp(adj)) 
    adj = "";
  return declinateArticle(g, casus, demon) + adj + n + ob->getSuffix();
}

/*
 *  PossesivePrononem in allen moeglichen Faellen.
 *  from:  entweder das Objekt, auf das sich das Pronomen bezieht
 *         oder das Geschlecht dieses Objekts
 *         oder ein Array mit ({Geschlecht, Plural}) des Objeckts
 *  gender: Geschlecht des Besitzers, erweitert auf alle Personenformen,
 *          (NEUTER, MALE, FEMALE, ICH, DU, WIR, IHR, SIE)
 *  casus: Fall (WER, WESSEN, WEM, WEN)
 *  plural: Plural (0 oder 1)
 */
varargs string getPossPronoun(mixed from, int gender, int casus, int plural)
{
  int fromGender;
  int fromPlural;

  if (intp(from)) {
    fromGender = from;
    fromPlural = 0;
  } 
  else if (pointerp(from)) {
    fromGender = from[0];
    fromPlural = from[1];
  }
  else {
    fromGender = from->getGender();
    fromPlural = (from->getPlural() == 1);
  }
  return ({"sein", "sein", "ihr", "mein", "dein", "unser", "euer", "ihr"}) [gender % 8] + 
    getDeclinationSuffix(fromGender, casus, plural);
}

/*
 *  Pronomen in allen moeglichen Faellen.
 *  gender: Geschlecht, erweitert auf alle Personenformen,
 *          (NEUTER, MALE, FEMALE, ICH, DU, WIR, IHR, SIE)
 *  casus: Fall (WER, WESSEN, WEM, WEN)
 */
varargs string getPronoun(int gender, int casus)
{
  return ({ ({"es", "seiner", "ihm", "es"}),
            ({"er", "seiner", "ihm", "ihn"}),
            ({"sie", "ihrer", "ihr", "sie"}), 
            ({"ich", "meiner", "mir", "mich"}),
            ({"du", "deiner", "dir", "dich"}),
            ({"wir", "unser", "uns", "uns"}),
            ({"ihr", "euer", "euch", "euch"}),
            ({"sie", "ihr", "ihnen", "sie"}), }) [gender % 8][casus % 4];
}

string getGenderString(int gender)
{
  switch (gender % 3)
  {
    case MALE  : return "maennlich";
    case FEMALE: return "weiblich";
    case NEUTER: return "saechlich";
  }
}

