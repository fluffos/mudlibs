#include "../def.h"
#include <npcmaster.h>


void create()
{
  if (is_clone(this_object()))
  {
    destruct(this_object());
    return;
  }
  seteuid(getuid(this_object()));
}

string check_kerben(object pl)
{
  string given_scores;
  int i;
  string *npcs;
  string npcname;
  mixed *score;
  string answer;
  object npc;
  object ob;
  object next;

  if (strstr(getuid(previous_object()), "feyaria") == -1)
    return 0;
  npcs = ({});
  given_scores = pl->QueryScores();

  for (i = 6 * strlen(given_scores) - 1; i > 0; i--)
  {
    if (!test_bit(given_scores, i))
    {
      if (pointerp(score = NPCMASTER->QueryNPCbyNumber(i)))
      {
        if (score[1] > 0)
          npcs += ({score[2]});
      }
    }
  }
  npcname = npcs[random(sizeof(npcs))];
  catch(npc = clone_object(npcname));
  if (!objectp(npc))
    return 0;

  answer = "Du koenntest noch " + npc->name(WEN,1) + " jagen. Du findest dieses Wesen in "
    "der Region "+ capitalize(explode(npcname, "/")[1]) + ".";

  npc->move("/room/npcasylraum", M_NOCHECK);
  for (ob = first_inventory(npc); ob;) 
  {
    next = next_inventory(ob);
    ob->remove();
    ob = next;
  }
  npc->remove();
  if (objectp(npc)) 
    destruct(npc);

  return answer;
}

