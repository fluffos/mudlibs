// MorgenGrauen MUDlib
//
// LIVING/LIFE.C -- life variables 
//
// $Date: 1995/07/24 11:07:40 $                      
// $Revision: 2.42 $       
/* $Log: life.c,v $
 *
 * Revision 2.43  1996/04/16  00:50:00  Woody@Silberland
 * P_CORPSE_PROPS eingefuehrt
 *
 * Revision 2.42  1995/07/24  11:07:40  Wargon
 * Gift etwas logischer gemacht.
 * Zufallselement in Ueberwindung der Vergiftung eingebaut.
 *
 * Revision 2.41  1995/07/20  15:41:57  Boing
 * Kleine SChoenheitskorrektur an der alignment-Berechnung
 *
 * Revision 2.40  1995/07/19  12:37:44  Jof
 * Ghosts dont die
 *
 * Revision 2.39  1995/07/19  12:34:29  Wargon
 * Gift ein wenig geaendert.
 *
 * Revision 2.38  1995/07/19  11:46:19  Boing
 * Alignment-Veraenderung wird nach einer neuen Formel berechnet, die
 * alte Formel war viel zu krass.
 *
 * Revision 2.37  1995/05/22  07:16:27  Jof
 * Minor speedups
 *
 * Revision 2.37  1995/05/21  20:20:14  mud
 * Minor speedups
 *
 * Revision 2.36  1995/04/27  19:39:31  Jof
 * removed some unnecessary ME->'s
 *
 * Revision 2.35  1995/04/05  20:09:53  Jof
 * Dont give xp if we dont have xp
 *
 * Revision 2.34  1995/03/21  19:38:14  Boing
 * Magier koennen jetzt essen und trinken so viel sie wollen.
 *
 * Revision 2.33  1995/01/31  15:46:06  Jof
 * current_object d/gebirge/boing/sm/mon/killerpopel#268339 destructed beseitigt
 * SetProp(P_HP) in do_damage vorgezogen zu diesem zwecke
 *
 * Revision 2.32  1994/12/28  20:21:18  Jof
 * Revision 2.31  1994/12/06  10:11:38  Boing
 * Neue Prop P_KILLER wird im Todesfall auf das toetende Objekt gesetzt.
 *
 * Revision 2.30  1994/11/30  01:03:41  Kirk
 * Set(P_DEADS) in die()
 *
 * Revision 2.29  1994/11/30  00:34:17  Kirk
 * counting num of deads
 *
 * Revision 2.28  1994/10/04  09:45:53  Jof
 * Revision 2.29  1994/10/04  13:54:50  mud
 * Revision 2.28  1994/10/03  22:07:17  mud
 * Revision 2.27  1994/08/30  13:50:04  Jof
 * Revision 2.26  1994/08/24  17:56:49  Jof
 * fixed show_age
 *
 * Revision 2.25  1994/06/13  20:14:32  Rochus
 * /log/KILLS Eintrag geaendert.
 *
 * Revision 2.24  1994/06/13  07:36:24  Jof
 * Removed SET_METHODs
 *
 * Revision 2.23  1994/05/26  19:07:24  Rochus
 * Kein do_damage mehr, wenn der Gegner ein Geist ist.
 *
 * Revision 2.22  1994/05/15  18:11:04  Jof
 * Revision 2.21  1994/05/05  12:42:38  Highlander
 * Corpse nach wahl mit P_CORPSE
 *
 * Revision 2.20  1994/05/02  17:24:34  Hate
 * capitalized messages for poison
 *
 * Revision 2.19  1994/03/30  12:32:57  Hate
 * changed drink messages to tell_object(ME
 *
 * Revision 2.18  1994/03/25  12:48:29  Jof
 * Logging kills
 *
 * Revision 2.17  1994/03/21  16:48:13  Jof
 * Revision 2.16  1994/03/18  12:35:53  Jof
 * Revision 2.15  1994/02/25  09:58:15  Highlander
 * DAs miit dem alte Version holen muss ich mal ueben...
 *
 * Revision 2.14  1994/02/25  09:53:56  Highlander
 * der Koehler sagt: <Hick>!  - capitalize drumrumgemahcht auf Bitte Troy
 *
 * Revision 2.13  1994/02/24  13:04:42  Highlander
 * Endlich gefunden, warum das poisonlog so zugemluellt wurde. Beseitigt.
 *
 * Revision 2.12  1994/02/24  13:02:34  Jof
 * Private removed
 *
 * Revision 2.11  1994/02/23  12:52:00  Highlander
 * Bug inserted last time killed again
 *
 * Revision 2.10  1994/02/23  12:48:37  Highlander
 * Au f der Suche nach doofen loggingtexten...
 *
 * Revision 2.9  1994/02/17  17:57:18  Kirk
 * void varargs die() -> varargs void die()  ;)
 *
 * Revision 2.8  1994/02/17  16:39:57  Highlander
 * Poison egeht erst mal
 *
 * Revision 2.3  1994/02/16  13:36:34  Highlander
 *
 * Revision 2.1  1994/01/17  22:18:10  mud
 * changed indentation
 *
 * Revision 2.0  1994/01/13  16:52:04  mud
 * Revision 1.4  1994/01/10  19:46:21  mud
 * Bug in HP fixed
 */                            

// living object life variables
//
//  P_ALIGN         -- alignment value
//  P_NPC           -- if living is an NPC
//  P_HP            -- HitPoints
//  P_SP            -- SpellPoints
//  P_ALCOHOL       -- value of intoxication
//  P_DRINK         -- value of soakness
//  P_FOOD          -- value of stuffness
//  P_AGE           -- Age
//  P_XP            -- experience
//  P_POISON        -- level of poison
//  P_CORPSE        -- corpse-object
//  P_CORPSE_PROPS  -- corpse-object properties

#pragma strong_types

#define NEED_PROTOTYPES

#include <thing/properties.h>
#include <properties.h>
#include <config.h>
#include <health.h>
#include <wizlevels.h>
#include <language.h>
#include <moving.h>
#include <defines.h>
#include <combat.h>

#define ALCOHOL_VALUE(n) n

#include "log.h"

int age;                  /* Number of heart beats of this character. */

static int delay_alcohol; /* time until next alcohol effect */
static int delay_drink;   /* time until next drink effect */
static int delay_food;    /* time until next food effect */
static int delay_heal;    /* time until next heal effect */
static int delay_poison;  /* time until next poison effect */
static int drop_poison;

static int delay_temp;    /* time until next temperature effect */
static int delay_theal;   /* time until next heal effect if out of temprange */
static int htemp;
static mapping range;

// local properties prototypes
static int _set_align(int a);
static int _set_hp(int hp);
static int _set_sp(int sp);
static int _set_alcohol(int n);
static int _set_drink(int n);
static int _set_food(int n);
static int _set_poison(int n);
static int _query_age();
static int _set_xp(int xp);

void create() 
{
  Set(P_GHOST, SAVE, F_MODE);
  Set(P_FROG, SAVE, F_MODE);
  Set(P_ALIGN, SAVE, F_MODE);
  Set(P_HP, SAVE, F_MODE);
  Set(P_SP, SAVE, F_MODE);
  Set(P_XP, SAVE, F_MODE);

  Set(P_ALCOHOL, SAVE, F_MODE);
  Set(P_DRINK, SAVE, F_MODE);
  Set(P_FOOD, SAVE, F_MODE);
  Set(P_POISON, SAVE, F_MODE);

  Set(P_AGE, -1, F_SET_METHOD);
  Set(P_AGE, PROTECTED, F_MODE);
  SetProp(P_CORPSE, "/std/corpse");
}

/*
 * This function is called from other players when they want to make
 * damage to us. But it will only be called indirectly.
 * We return how much damage we received, which will
 * change the attackers score. This routine is probably called from
 * heart_beat() from another player.
 * Compare this function to reduce_hit_point(dam).
 */
int do_damage(int dam, mixed enemy) 
{
  int hit_point;

  if (QueryProp(P_GHOST) || dam<=0 || 
      (objectp(enemy) && enemy->QueryProp(P_GHOST)))
    return 0;
  hit_point = QueryProp(P_HP)-dam;
  if (QueryProp(P_XP) && enemy)
    enemy->AddExp(dam*(int)QueryProp(P_TOTAL_WC)/10);
  SetProp(P_HP, hit_point);
  if (hit_point<0) {
    if (enemy)
    {
      enemy->StopHuntFor(ME,1);
      enemy->AddExp(QueryProp(P_XP)/100);
      if (!query_once_interactive(ME))
        log_file ("NPC_XP", file_name(ME) + ", XP: " +
                  (QueryProp(P_XP)/100) + ", HP*WC: " +              
                  ME->QueryProp(P_TOTAL_WC)
                  *ME->QueryProp(P_MAX_HP)/10 
                  +", Killer: " + enemy->name(RAW) + "\n");  
      enemy->SetProp(P_ALIGN, enemy->QueryProp(P_ALIGN)*9/10 -
		     QueryProp(P_ALIGN)/4);
    }
    SetProp(P_KILLER, enemy);
    StopHuntingMode(1);
    ME->die();
  }
  return dam;
}

void transfer_all_to(mixed dest)
{
  object *ob;

  ob = all_inventory(ME);
  while(sizeof(ob))
  {
    if ( ! ob[0]->QueryProp( P_NEVERDROP ) )
      ob[0]->move(dest,M_SILENT|M_NOCHECK); /* no unwield messages */
    ob = ob[1..];
  }
  SetProp(P_USED_HANDS,0);
}

static void create_kill_log_entry(string killer) {
  string tmp;
  int level,lost_exp;
  object me;

  me=ME;
  tmp=dtime(time());;
  if ((level=me->QueryProp(P_LEVEL))<20)
    lost_exp = me->QueryProp(P_XP)/3;
  else
    lost_exp = me->QueryProp(P_XP)/(level-17);
  log_file("KILLS",
               tmp[5..11]+" "+tmp[19..23]+" "+
               capitalize(getuid(me))+
                   "("+level+","+(lost_exp/1000)+") "+
               killer+"\n");
}

varargs void die(int poisondeath) {
  object corpse;
  string die_msg;
  string tmp, tmp2;
  mapping props;
  mixed *ind;
  int i;

  if (QueryProp(P_GHOST)) return; // Ghosts dont die ...
  if (query_once_interactive(this_object()) && QueryProp(P_POISON))
    SetProp(P_POISON, 0); /* Don't die twice 'cause of the same poison */
  map_objects( ME->QueryEnemies()[0], "StopHuntFor", ME, 1 );
  ME->StopHuntingMode(1);
  if (IS_LEARNING(ME) && query_once_interactive(ME))
  {      
    tell_object(ME,
                "Sei froh dass Du unsterblich bist, sonst waere es eben Dein"
                " Ende gewesen.\n");
    return;
  }

  if (query_once_interactive(ME) && extern_call() && 
      previous_object()!=this_object())
  {
    tmp=dtime(time());
    corpse=previous_object()||this_interactive()||this_player();
    if (corpse)
    {
      tmp2=explode(file_name(corpse),"#")[0]+" (direkt !)";
      if (strlen(tmp2)>33) tmp2="..."+tmp2[<31..];
      create_kill_log_entry(tmp2+" ("+getuid(corpse)+")");
      log_file("Kills",sprintf("%s %s\n",getuid(ME),tmp2));
    }
  }
  if (query_once_interactive(ME))
    Set(P_DEADS,QueryProp(P_DEADS)+1);
  if( !(die_msg=QueryProp(P_DIE_MSG)) )
    die_msg = " faellt tot zu Boden.\n";
  if (poisondeath==2)
    die_msg = " wird von Kaelte hinweggerafft und kippt um.\n";
  else if (poisondeath==3)
    die_msg = " wird von Hitze hinweggerafft und kippt um.\n";
  else if (poisondeath)
    die_msg = " wird von Gift hinweggerafft und kippt um.\n";
  say( capitalize(ME->name(WER,1)) + die_msg );
  if (QueryProp(P_NOCORPSE)) 
    transfer_all_to(environment(ME));
  else
  {
    corpse = clone_object(QueryProp(P_CORPSE));
    if (!(QueryProp(P_CORPSE_FLAGS) & COR_NOSETWEIGHT))
      corpse->SetProp(P_WEIGHT,QueryProp(P_WEIGHT));
    corpse->Identify(ME);
    corpse->SetProp(P_HEAL, QueryProp(P_HEAL));
    if (!(QueryProp(P_CORPSE_FLAGS) & COR_NOINVTRANSFER))
      transfer_all_to(corpse);
    else
      transfer_all_to(environment(ME));
    if (props=QueryProp(P_CORPSE_PROPS))
    {
      ind = m_indices(props);
      for (i=sizeof(ind); i>0; i)
        corpse->SetProp(ind[--i], props[ind[i]]);
    }
    if (QueryProp(P_CORPSE_FLAGS) & COR_MSGIN)
      corpse->move(environment(ME),M_GO);
    else
      corpse->move(environment(ME),M_NOCHECK);
    if (QueryProp(P_CORPSE_FLAGS) & COR_KILLENEMY)
      corpse->Kill(QueryProp(P_KILLER));
  }
  SetProp(P_ALCOHOL, 0);
  if (!ME->second_life(corpse))
    ME->remove();
}

void heal_self(int h) {
  if(h <= 0) return;
  SetProp(P_HP, QueryProp(P_HP)+h);
  SetProp(P_SP, QueryProp(P_SP)+h);
}

void restore_spell_points(int h) {
  SetProp(P_SP, QueryProp(P_SP)+h);
}

/* Reduce hitpoints. Log who is doing it. */
int reduce_hit_point(int dam) {
  object o;
#ifdef LOG_REDUCE_HP
  if(this_player()!=ME) {
    log_file("REDUCE_HP", ME->name()+" by ");
    if(!this_player()) log_file("REDUCE_HP","?\n");
    else {
      log_file("REDUCE_HP",this_player()->name());
      o=previous_object();
      if (o)
        log_file("REDUCE_HP", " " + file_name(o) + ", " +
                 o->name(WER,0) + " (" + creator(o) + ")\n");
      else
        log_file("REDUCE_HP", " ??\n");
    }
  }
#endif
  if(SetProp(P_HP, QueryProp(P_HP) - dam) <= 0) SetProp(P_HP, 1);
  return QueryProp(P_HP);
}

int drink_alcohol(int strength)
{
  int alc;

  alc = QueryProp(P_ALCOHOL)+ALCOHOL_VALUE(strength);
  if ((alc >= QueryProp(P_MAX_ALCOHOL)) &&
      !IS_LEARNER(this_object()))
  {
    tell_object(ME, "So ein Pech, Du hast alles verschuettet.\n");
    return 0;
  }
  if(alc < 0) alc = 0;
  if(!alc) tell_object(ME, "Du bist stocknuechtern.\n");
  SetProp(P_ALCOHOL, alc);
  return 1;
}

int drink_soft(int strength)
{
  int soaked;

  soaked = QueryProp(P_DRINK);
  if((soaked + strength > QueryProp(P_MAX_DRINK)) &&
     !IS_LEARNER(this_object()))
  {
    tell_object(ME, "Nee, so viel kannst Du momentan echt nicht trinken.\n" );
    return 0;
  }
  if((soaked += DRINK_VALUE(strength)) < 0) soaked = 0;
  if(!soaked) tell_object(ME, "Dir klebt die Zunge am Gaumen.\n");
  SetProp(P_DRINK, soaked);
  return 1;
}

int eat_food(int strength)
{
  int stuffed;
  
  stuffed = QueryProp(P_FOOD);
  if ((stuffed + strength > QueryProp(P_MAX_FOOD)) && 
      !IS_LEARNER(this_object()))
  {
    tell_object(ME, 
    "Das ist viel zu viel fuer Dich! Wie waers mit etwas leichterem?\n");
    return 0;
  }
  stuffed += FOOD_VALUE(strength);
  if(stuffed < 0) stuffed = 0;
  if(!stuffed) tell_object(ME, "Was rumpelt denn da in Deinem Bauch?\n");
  SetProp(P_FOOD, stuffed);
  return 1;
}

static void heart_beat() {
  int hpoison;
  hpoison=QueryProp(P_POISON);
  age++;
  if(QueryProp(P_ALCOHOL) && !random(40)) {
    int n;
    switch(random(4)) {
      case 0:
      say(capitalize(ME->name(WER,1)) + " sagt: <Hick>!\n");
      write("<Hick>! Oh, Tschuldigung.\n");
      break;
      case 1:
      say(capitalize(ME->name(WER,1)) + " stolpert ueber " +
          ME->QueryPossPronoun(FEMALE,WEN) + " Fuesse.\n");
      write("Du stolperst.\n");
      break;
      case 2:
      write("Du fuehlst Dich benommen.\n");
      say(capitalize(ME->name(WER,1)) + " sieht betrunken aus.\n");
      break;
      case 3:
      say(capitalize(ME->name(WER,1)) + " ruelpst.\n");
      write("Du ruelpst.\n");
      break;
    }
  } 
  if(QueryProp(P_ALCOHOL) && --delay_alcohol < 0) {
    SetProp(P_ALCOHOL, QueryProp(P_ALCOHOL)-1);
    if (!hpoison) {
      SetProp(P_HP, QueryProp(P_HP)+1);
      SetProp(P_SP, QueryProp(P_SP)+1);
    }
    delay_alcohol = ALCOHOL_DELAY;
  }

  if(--delay_drink < 0) {
    delay_drink = DRINK_DELAY;
    SetProp(P_DRINK, QueryProp(P_DRINK)-1);
  }

  if(--delay_food < 0) {
    delay_food = FOOD_DELAY;
    SetProp(P_FOOD, QueryProp(P_FOOD)-1);
  }

  /* temperature handling */
  if (--delay_temp < 0) {
    delay_temp = TEMP_DELAY;
    htemp =
      QueryProp(P_TOTAL_TEMPERATURE_PROTECTION)+
      QueryProp(P_TEMPERATURE_OFFSET)+
      environment()->QueryProp(P_ENVIRONMENT)[ENV_TEMPERATURE]+
      environment()->QueryProp(P_TEMPERATURE_OFFSET);
    range = QueryProp(P_TEMPERATURE_RANGE);
    if (htemp < range[0])
      htemp = htemp - range[0];
    else if (htemp > range[1])
      htemp = htemp - range[1];
    else htemp = 0;
  }

  /* normal regeneration */
  if(--delay_heal < 0) {
    delay_heal = HEAL_DELAY;
    if ((htemp>-5) && (htemp<5)) {
      if (--delay_theal < 0) {
         delay_theal = THEAL_DELAY;
         SetProp(P_HP, QueryProp(P_HP)+1);
         SetProp(P_SP, QueryProp(P_SP)+1);
      }
    } else
    if (!hpoison && !htemp)  {
      SetProp(P_HP, QueryProp(P_HP)+1);
      SetProp(P_SP, QueryProp(P_SP)+1);
    }
  }

  if (htemp)
  {
    if (delay_temp==TEMP_DELAY)
    {
      int nhp;
      nhp = QueryProp(P_HP);
      nhp -= htemp<0 ? -htemp/5 : htemp/5;
      if (nhp<0) nhp=-1;
      SetProp(P_HP, nhp);
      if (nhp < 0)
      {
        tell_object(this_object(), "Oh weh - die "+
          (htemp<0 ? "Kaelte" : "Hitze")+
          " war zuviel fuer Dich!\nDu stirbst.\n");
        if (query_once_interactive(this_object()))
        {
          create_kill_log_entry("Temperatur");
          log_file("Kills", geteuid()+" TEMP\n");
        }
        this_object()->die(htemp<0 ? 2 : 3);
        return;
      }
    }
    // if (!random(15))
    if (random(200) < (htemp<0 ? -htemp : htemp))
    {
      if (htemp>19) {
        write("Die sengende Hitze macht Dir schwer zu schaffen.\n");
        say(capitalize(ME->name(WER))+" leidet arg unter der sengenden Hitze.\n", ({ME}));
      } else if (htemp<-19) {
        write("Die klirrende Kaelte macht Dir schwer zu schaffen.\n");
        say(capitalize(ME->name(WER))+" leidet arg unter der klirrenden Kaelte.\n", ({ME}));
      } else
      switch (htemp)  {
        case -19..-15:
         write("Du frierst am ganzen Leib ob der Kaelte.\n");
         say(capitalize(ME->name(WER))+" friert und zittert am ganzen Leib.\n", ({ME}));
         break;
        case -14..-10:
         write("Du klapperst vor Kaelte mit den Zaehnen.\n");
         say(capitalize(ME->name(WER))+" klappert vor Kaelte mit den Zaehnen.\n", ({ME}));
         break;
        case -9..-5:
         write("Du frierst etwas.\n");
         say(capitalize(ME->name(WER))+" scheint etwas zu frieren.\n", ({ME}));
         break;
        case -4..-1:
         write("Dich froestelt leicht.\n");
         say(capitalize(ME->name(WER))+" froestelt leicht.\n", ({ME}));
         break;
        case 1..4:
         write("Dir ist ein wenig heiss.\n");
         say(capitalize(ME->name(WER))+" scheint etwas heiss zu sein.\n", ({ME}));
         break;
        case 5..9:
         write("Du wischt Dir den Schweiss von der Stirn. Ganz schoen warm!\n");
         say(capitalize(ME->name(WER))+" wischt sich den Schweiss von der Stirn.\n", ({ME}));
         break;
        case 10..14:
         write("Du schwitzt ziemlich stark.\n");
         say(capitalize(ME->name(WER))+" schwitzt ziemlich stark.\n", ({ME}));
         break;
        case 15..19:
         write("Du stoehnst unter der Hitze.\n");
         say(capitalize(ME->name(WER))+" stoehnt unter der Hitze.\n", ({ME}));
         break;
      }
    }
  }

  if (hpoison)  {
    int lhp;
    lhp=QueryProp(P_HP);
    hpoison--;
    if (--delay_poison < 0) {
      delay_poison = POISON_DELAY + random(POISON_MERCY_DELAY);
      lhp -= hpoison;
      if (lhp<0) lhp=-1;
      SetProp(P_HP, lhp);
      if (lhp < 0)  {
        tell_object(this_object(), "Oh weh - das Gift war zuviel fuer Dich!\n"
                    +"Du stirbst.\n");
        if (query_once_interactive(this_object()))
        {
          create_kill_log_entry("Vergiftung");
          log_file("Kills", geteuid()+" GIFT\n");
        }
        this_object()->die(1);
        return;
      }
      if (hpoison < 3 && --drop_poison < 0) {
        switch(hpoison) {
        case 1:
          drop_poison += (15+random(6));  // Das werden etwa 50...
        case 2:
          drop_poison += (25+random(10));
        case 0:
          Set( P_POISON, hpoison);
          if (!hpoison)
            tell_object(this_object(), "Du scheinst die Vergiftung ueberwunden zu haben.\n" );
          break;
        }
      }
    }
    if (hpoison && !random(15))
      switch (QueryProp(P_HP)*100/QueryProp(P_MAX_HP))  {
        case 71..100 :
        write("Du fuehlst Dich nicht gut.\n");
        say(capitalize(ME->name(WER))+" sieht etwas benommen aus.\n", ({ME}));
        break;
        case 46..70 :
        write("Dir ist schwindlig und Dein Magen revoltiert.\n");
        say(capitalize(ME->name(WER))+" taumelt ein wenig.\n", ({ME}));
        break;
        case 26..45 :
        write("Dir ist heiss. Du fuehlst Dich schwach. Kopfweh hast Du "
              +"auch.\n");
        say(capitalize(ME->name(WER))+" glueht direkt und scheint grosse "
            +"Schwierigkeiten zu haben.\n", ({ME}));
        break;
        case 11..25 :
        write("Du fuehlst Dich beschissen. Alles tut weh, und Du siehst "
              +"nur noch unscharf.\n");
        say(capitalize(ME->name(WER))+" taumelt und stoehnt und kann gerade "
            +"noch vermeiden, hinzufallen.\n", ({ME}));
        break;
        case 0..10 :
        write(break_string("Du siehst fast nichts mehr und kannst Dich nur "
                           +"noch unter groessten Schmerzen bewegen. Aber bald tut nichts "
                           +"mehr weh...", 78));
        say(break_string(capitalize(ME->name(WER))+" glueht wie im Fieber, "
                         +"kann sich kaum noch ruehren und hat ein schmerzverzerrtes "
                         +"Gesicht.\n", 78), ({ME}));
        break;
      }
  }
}

void show_age()
{
  int i,j;

  write("Alter:\t");
  i = QueryProp(P_AGE);
  if ((j=i/43200))
  {
    write(j + " Tag"+(j==1?" ":"e "));
    i %= 43200;
  }
  if ((j=i/1800))
  {
    write(j + " Stunde"+(j==1?" ":"n "));
    i %= 1800;
  }
  if ((j=i/30))
  {
    write(j + " Minute"+(j==1?" ":"n "));
    i %= 30;
  }
  write(i*2 + " Sekunden.\n");
}

int AddExp(int e)
{
  int experience;
  
  experience = QueryProp(P_XP);
  if(QueryProp(P_KILLS)>1 && e>0) return experience;
  if((experience+=e) < 0) experience = 0;
  return SetProp(P_XP, experience);
}

int add_exp(int e)
{
  return AddExp(e);
}

static int _set_align(int a) {
  if (a<-1000) a = -1000;
  if (a>1000) a = 1000;
  return Set(P_ALIGN, a);
}

static int _set_hp(int hp) {
  if(hp < 0) return Set(P_HP, 0);
  if(hp > QueryProp(P_MAX_HP)) return Set(P_HP, QueryProp(P_MAX_HP));
  return Set(P_HP, hp);
}

static int _set_sp(int sp) {
  if(sp < 0) return Set(P_SP, 0);
  if(sp > QueryProp(P_MAX_SP)) return Set(P_SP, QueryProp(P_MAX_SP));
  return Set(P_SP, sp);
}

static int _set_alcohol(int n) {
  return Set(P_ALCOHOL, (n < 0 ? 0 : n));
}

static int _set_drink(int n) {
  return Set(P_DRINK, (n < 0 ? 0 : n));
}

static int _set_food(int n) {
  return Set(P_FOOD, (n < 0 ? 0 : n));
}

static int _set_poison(int n)  {
  n = (n<0 ? 0 : (n>MAX_POISON ? MAX_POISON : n));

  if (Query(P_POISON) == 0 && n==0)
    return 0;

  log_file("POISON", sprintf("%s - %s: %d von %O (%s)\n",
           dtime(time())[5..],
           (query_once_interactive(this_object()) ?
             capitalize(geteuid(this_object())) : 
             capitalize(ME->name(WER))),
           n,
           (previous_object(2) ? previous_object(2) : previous_object(1)),
           (this_player() ? capitalize(geteuid(this_player())) : "???")));

  switch(n) {
  case 1:
    drop_poison = 40+random(16);
    break;
  case 2:
    drop_poison = 25+random(8);
    break;
  case 3:
    drop_poison = 18+random(4);
    break;
  }
  return Set(P_POISON, n);
}

static int _query_age() { return Set(P_AGE, age); }

static int _set_xp(int xp) { return Set(P_XP, xp < 0 ? 0 : xp); }
