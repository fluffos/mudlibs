//Cracked by Roath
//  ����֮�� ������
//  by happ@YSZZ 2000.4.7
//  /d/qujing/village/npc/girl1.c

inherit NPC;
#include <ansi.h>

void create()
{
   set_name(HIG"����"NOR, ({ "zhen zhen", "zhenzhen"}));
   set("gender", "Ů��" );
   set("age", 15);
   set("long",
     "һλ��ɫ��Ů��\n");

   set_level(40);
   set("attitude", "friendly");
   set_skill("dodge", 10);
   set_skill("unarmed", 10);
   setup();
   carry_object("/obj/cloth")->wear();
   add_money("silver", 3+random(20));
}

