// by snowcat  11/22/1997

inherit NPC;

void create()
{
  set_name("Сͯ", ({"kid"}));
  if (random(2))
    set("gender", "����");
  else
    set("gender", "Ů��");
  set_level(2);
  set("age", 3+random(5));
  set("per", 14+random(20));
  set("attitude", "friendly");
  set("shen_type", 1);
  set("people", "people");
  set("force_factor",2);
  setup();
  carry_object("/d/obj/cloth/linen")->wear();
}


