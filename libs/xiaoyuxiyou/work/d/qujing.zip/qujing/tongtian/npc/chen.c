// rewritten by snowcat on 12.12.1997

inherit NPC;

void create()
{
  set_name("�³���", ({"chen zhanglao", "chen", "zhanglao"}));
  set("gender", "����");
  set("age", 70);
  set("attitude", "friendly");
  set_level(5);

  set_skill("dodge", 30);
  set_skill("force", 30);
  set_skill("parry", 30);
  set("force_factor",5);
  setup();

  carry_object("/d/obj/cloth/choupao")->wear();

}