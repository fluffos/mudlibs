// created by wxb 12/24/1998
// room: /d/qujing/huangfeng/npc/xiaoer.c

inherit F_VENDOR_SALE;

void create()
{
       set_name("��С��", ({"wang xiaoer", "wang","xiaoer","er","waiter" }));
       set("long", "С�Ƶ�Ļ�ƣ�һ������������ģ����\n");
       set("gender", "����");
	set("title", "���");
	set("combat_exp", 3000);
       set("age", 46);
       set("attitude", "friendly");
       set("shen_type", 1);
       set_skill("unarmed", 10);
        set("vendor_goods", ([
                "jiudai": "/d/ourhome/obj/hdjiudai",
                "gourou": "/d/ourhome/obj/gourou",
                "yumi": "/d/qujing/huangfeng/obj/yumi",
		    "mifan": "/d/qujing/huangfeng/obj/mifan",
        ]) );

	setup();
       add_money("silver", 2);
	add_money("coin", random(80));
        carry_object("/obj/cloth")->wear();

}