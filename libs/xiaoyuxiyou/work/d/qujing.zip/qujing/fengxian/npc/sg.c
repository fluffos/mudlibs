// by snowcat 11/6/1997

inherit NPC;

void create()
{
  set_name("�Ϲٿ���", ({"shangguan junzhu", "junzhu", "zhu"}));
  set("title", "���ɿ�");
  set("long", "���ù����ɿ���һ��֮�\n");
  set("gender", "����");
  set_level(10);
  set("age", 50);
  set("per", 25);
  set("attitude", "peaceful");
  set("shen_type", 1);
  set("combat_exp", 200000);
  set_skill("unarmed", 100);
  set_skill("dodge", 100);
  set_skill("parry", 100);
  set("max_gin",800);
  set("max_kee",800);
  set("max_sen",800);
  set("max_force",1000);
  set("max_mana",1000);
  set("force_factor",120);
  set("eff_dx",15000);
  set("nkgain",90);
  setup();
  carry_object("/d/obj/cloth/choupao")->wear();
  carry_object("/d/obj/weapon/blade/fengdao")->wield();
}