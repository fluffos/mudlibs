inherit NPC;
void create()
{
        set_name("«��", ({"lu niang"}));
        set("long",
"��ͷ�ϲ��ż����ɫ«����������Ȼ������ȴ�ڲ�ס���ϵ�������\n");
        set("age", 20);
	set("title", "«����");
        set("attitude", "friendly");
        set("gender", "Ů��");
	set("class", "yaomo");
	set_level(89);

	set("eff_dx", -60000);
        set("nkgain", 330);

        set("force_factor", 30);
        set("mana_factor", 20);
        set_skill("unarmed",890);
        set_skill("force",890);
        set_skill("spells",890);
        set_skill("dodge", 890);
	set_skill("parry",890);
	set_skill("whip",890);
	set_skill("moondance",890);
	set_skill("snowwhip",890);
	map_skill("whip", "snowwhip");
	map_skill("parry", "snowwhip");
	map_skill("dodge", "moondance");
        setup();
        carry_object("/d/obj/cloth/skirt")->wear();
	carry_object("/d/qujing/bibotan/obj/luhua")->wield();
}
void init()
{
        object ob;

        ::init();
        if( interactive(ob = this_player()) && !is_fighting() ) {
                remove_call_out("greeting");
                call_out("greeting", 3, ob);
        }
}

void greeting(object ob)
{
        if( !ob || !present(ob, environment(this_object())) ) return;
	
	if((string)ob->query("family/family_name")=="�ݿ�ɽ�޵׶�" 
	&& (string)ob->query("family/family_name")=="��ʯɽ�̲�̶"
        && (string)ob->query("family/family_name")=="��ѩɽ") {
	command("xixi " + ob->query("id"));
	return;
	}
	command("look " + ob->query("id") );
	command("say �ְ����֣���������θ�ڡ�");
	command("chan " + ob->query("id") );
	kill_ob(ob);
	ob->fight_ob(this_object());

	return;
}