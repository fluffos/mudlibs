inherit NPC;
void create()
{
	int i = 30+random(20);
        set_name("ˮ�߹�", ({"shuishe guai", "guai"}));
        set("long", "һ������ϸ����ˮ�߹֣����ų߳���о�ӣ��������Ŷ����\n");
        set("age", 30);
        set("attitude", "aggressive");
        set("gender", "����");
	set("class", "yaomo");
        set("per", 10);
        set_level(i);
	set_temp("apply/armor", 10);
	set("bellicosity", 2000);

	set("eff_dx", -5000);
        set("nkgain", 120);

        set("force_factor", 5);
        set("mana_factor", 5);
        set_skill("unarmed",i*10);
        set_skill("force",i*10);
        set_skill("spells",i*10);
        set_skill("dodge",i*10);
	set_skill("parry",i*10);
	set_skill("cuixin-zhang",i*10);
	map_skill("unarmed", "cuixin-zhang");
        setup();
}
int heal_up()
{

        if( environment() && !is_fighting() ) {
                call_out("leave", 1);
                return 1;
        }
        return ::heal_up() + 1;
}

void leave()
{
	object stone;
	
	this_object()->add("time", 1);
	if( (int)this_object()->query("time") >= 6 ) {
        message("vision",name() + "�����̡�һ�������ص�ˮ�С�\n", environment(),this_object() );
        destruct(this_object());

	}
	return;
}
