// created by snowcat on 12/9/1997

inherit NPC;

string *names = ({
  "�ʨ",
  "ѩʨ",
  "��ʨ",
  "����ʨ",
  "����ʨ",
  "��ʨ",
  "�Ʊ�",
  "ˮ��",
  "����",
  "ʯ��",
  "�ݱ�",
  "ɽ��",
  "��ë��",
  "���滢",
  "���߻�",
  "������",
  "�˽Ż�",
  "˫β��",
});

void create()
{
  int i = random(15)+40;
  string str;
  set_name(names[random(sizeof(names))], ({"yao guai", "yao", "guai"}));
  set("gender", "����");
  set("age", 30+random(30));
  set("attitude", "aggressive");
  set_level(i);
  set("per", 10);
  set_skill("parry", 10*i);
  set_skill("unarmed", 10*i);
  set_skill("dodge", 10*i);
  set_skill("blade", 10*i);
  set_skill("fork", 10*i);
  set_skill("mace", 10*i);
  set_skill("spear", 10*i);
  set_skill("sword", 10*i);
  set_skill("whip", 10*i);
  set_skill("axe", 10*i);
  set_skill("hammer", 10*i);
  set_skill("rake", 10*i);
  set_skill("stick", 10*i);
  set_skill("staff", 10*i);
  set_skill("dagger", 10*i);
  set("force_factor",10*i);
  setup();
  carry_object("/d/qujing/zhujie/obj/cloth2")->wear();
  str = "/d/qujing/zhujie/obj/weapon20";
  str[strlen(str)-1] = '0'+random(4);
  carry_object(str)->wield();
}