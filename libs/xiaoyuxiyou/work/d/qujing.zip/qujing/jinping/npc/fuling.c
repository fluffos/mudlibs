#include <ansi.h>

inherit NPC;

void create()
{
  set_name("����", ({ "fu ling", "ling" }) );
  set("gender", "����");
  set("age", 50);
  set_level(20);
  set("attitude", "heroism");
  set_skill("unarmed",160);
  set_skill("parry", 160);
  set_skill("dodge", 160);

  setup();

  carry_object("/d/obj/cloth/changpao")->wear();
}