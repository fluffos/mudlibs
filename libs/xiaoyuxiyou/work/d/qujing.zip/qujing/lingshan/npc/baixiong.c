// snowcat 12 14 1997

inherit NPC;

void create()
{
  set_name("��������", ({ "baixiong zunzhe", "baixiong", "zunzhe" }));
  set_level(140);
  set("title", "��ɽ");
  set("gender", "����");
  set("age", 1000);
  set("attitude", "peaceful");
  set("str",40);
  set("force_factor", 80);
  set("mana_factor", 80);

  set_skill("literate",1400);
  set_skill("spells",1400);
  set_skill("buddhism",1400);
  set_skill("unarmed",1400);
  set_skill("jienan-zhi",1400);
  set_skill("dodge",1400);
  set_skill("lotusmove",1400);
  set_skill("parry",1400);
  set_skill("force",1400);
  set_skill("lotusforce",1400);
  set_skill("staff",1400);
  set_skill("lunhui-zhang",1400);
  map_skill("spells", "buddhism");
  map_skill("unarmed", "jienan-zhi");
  map_skill("dodge", "lotusmove");
  map_skill("force", "lotusforce");
  map_skill("parry", "lunhui-zhang");
  map_skill("staff", "lunhui-zhang");
  

  setup();
  carry_object("/d/obj/cloth/jia_sha")->wear();
}