//Cracked by Roath
//mingyue.c

inherit NPC;

int max_tea = 20;
void create()
{
	set_name("����", ({"ming yue", "mingyue"}));
      set_level(14);
	set("gender", "����" );
	set("age", 16);
	set("long", "һ������ϲ����С��ͯ��\n");
	set("class", "xian");
	set("combat_exp", 10000);
  set("daoxing", 20000);

	set("attitude", "peaceful");
	set("title", "С��ͯ");
	set_skill("unarmed", 140);
	set_skill("dodge", 140);
	set_skill("parry", 140);

	set("per", 20);
	set("max_kee", 200);
	setup();
	carry_object(0,"cloth",random(2))->wear();
	carry_object(0,"shoes",random(2))->wear();
}