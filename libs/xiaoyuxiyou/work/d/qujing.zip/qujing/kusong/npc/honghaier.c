//Cracked by Roath
inherit NPC;
inherit F_MASTER;
#include <ansi.h>
int ask_niang(object me);
int do_yes();

int rank_me();

void create()
{
	set_name("�캢��", ({"honghai er","er"}));
       	set_level(120);
       	create_family("���ƶ�", 2, "��");
        set("title", "ʥӤ����");
        set("long", "ţħ������ɲŮ�Ķ��ӣ��ڻ���ɽ��������һ���ñ��졣\n");
       	set("gender", "����");
       	set("age", 16);
        set("attitude", "heroism");

        set("eff_dx", -500000);
        set("nkgain", 500);
        set("class","yaomo");
        set("force_factor", 100);
        set("mana_factor", 80);
       
        set_skill("unarmed", 1150);
        set_skill("dodge", 1200);
        set_skill("force", 1150);
        set_skill("parry", 1150);
        set_skill("spear", 1180);
        set_skill("spells", 1150);
        set_skill("huoyun-qiang", 1180);
        set_skill("moshenbu", 1200);
        set_skill("moyun-shou", 1150);
        set_skill("huomoforce", 1180);
        set_skill("pingtian-dafa", 1150);

        map_skill("force", "huomoforce");
        map_skill("spells", "pingtian-dafa");
        map_skill("unarmed", "moyun-shou");
        map_skill("dodge", "moshenbu");
        map_skill("parry", "huoyun-qiang");
        map_skill("spear", "huoyun-qiang");

        set("kusong/Teach_Hong", 1);
        set("chat_chance_combat", 30);
        set("chat_msg_combat", ({
                (: cast_spell, "sanmei" :),
        }));


        

        set("inquiry", ([
//                "ְλ": (: rank_me :),
   //             "���ȹ���": (: ask_niang :),
]) );


        setup();
        carry_object("/d/nanhai/obj/huojianqiang")->wield();
        carry_object("/d/qujing/bibotan/obj/zhanpao")->wear();
}


void die()
{
   object ob=this_object();
  message_vision(HIY"���ϴ��������������������캢�����������һ��Ϻ�ȥ��\n"NOR,ob);
  destruct (ob);
}

void unconcious ()
{
  die();
}
