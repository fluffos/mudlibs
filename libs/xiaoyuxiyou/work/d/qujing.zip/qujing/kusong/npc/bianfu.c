//Cracked by Roath
inherit NPC;

void create()
{
  set_name("����", ({"bianfu jing","jing"}));
  set_level(43);
  set("gender", "����");
  set("age", 40);
  set("long","һ����ü���۵���������\n");

  set("per", 15);
  set_skill("dodge",430);
  set_skill("parry",430);
  set_skill("unarmed",430);
  set_skill("force",430);
  set_skill("spells",430);
  set_skill("dagger",430);
  set("force_factor", 25);
  set("mana_factor", 25);

  setup();
  carry_object("/d/qujing/kusong/obj/needle0")->wield();
  carry_object("/d/qujing/kusong/obj/tongjia")->wear();
}