// created 11/20/1997 by snowcat

inherit NPC;

void create()
{
  set_name("Сͯ", ({"xiao tong", "tong"}));
  set("gender", "����");
  set("age", 12);
  set_level(5);
  set("long", "һλͷ�����ݵĵ�ͯ��\n");
  set("attitude", "friendly");
  set_skill("unarmed", 30);
  set_skill("dodge", 50);
  set_skill("parry", 50);
  setup();
  carry_object("/d/obj/cloth/daopao")->wear();
}

