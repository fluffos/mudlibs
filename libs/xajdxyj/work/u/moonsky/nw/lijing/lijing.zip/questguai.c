//  "/u/oldcat/lijing/questguai"
//clone a guai : piao 3/19/2000

#include <ansi.h>;
inherit  "/u/oldcat/lijing/npcskill.c";
#include <command.h>
#include <guainame.h>

//1,moon,2,fangcun,3,putuo,4,hell,5,longgong,6,xueshan
//7,wudidong

object me=this_object(),questob,killertemp;
string username;
string guaiobname,*guaikeysa,*guaikeysb,*guaiobid;
int s1,s2;

void rewardskill(object ob);
void create()
{  
   int level,chooseguai;
   object guai;   
   string guainame,*guaiid;
   string fname,sname,tname;//firstname,secondname,thirdname,
   string *fname_key,*sname_key,*tname_key,*name_key;
   int f,s,t,n;
   
     
//���³������ֵ�����
   if (random(11)>3)
    {
      fname_key=keys(f_name);
      sname_key=keys(s_name);
      tname_key=keys(t_name);
      f=sizeof(fname_key);
      s=sizeof(sname_key);
      t=sizeof(tname_key);
      f=random(f-1);
      s=random(s-1);
      t=random(t-1);
      guainame=fname_key[f]+sname_key[s]+tname_key[t];
      guaiid=({f_name[fname_key[f]]+s_name[sname_key[s]]+" "
               +t_name[tname_key[t]],t_name[tname_key[t]]});
     }
   else 
     {
       name_key=keys(an_name);
       n=sizeof(name_key);
       n=random(n-1);
       if (random(11)>5)
        {
           guainame=name_key[n]+"��";
           guaiid=({an_name[name_key[n]]+" guai","guai"});
        }
       else 
        {
           guainame=name_key[n]+"��";
           guaiid=({an_name[name_key[n]]+" jing","jing"});
        }
      }
   set_name(guainame,guaiid);       	 
               
//�����������,

   set("gender","����");
   set("force_factor",150);
   set("mana_factor",150);    
   set("env/wimpy", 30);
   set("per",100);
   set("age",100);
   set("bellicosity",800);
   set("attitude", "friendly");
   set_temp("apply/armor",60);
   set("chat_chance",10);
   set("chat_msg",({
   (:random_move:)}));
   set("chat_chance_combat",random(50));
//   set("chat_msg_combat", ({
//     (: cast_spell, "bighammer" :),
//   }) );
   setup();
   
}

void rewardskill(object ob)
{  
   int s,i=0,maxlevel=1;
   string *str;
   mapping userskills;
   userskills=ob->query_skills();
   if (!mapp(userskills)) return;
   str=keys(userskills);
   s=sizeof(str);
   if (s==0) return;
   if (s<2) 
     {
     	userskills[str[0]]+=1; 
     	tell_object(ob,HIR"��õ���һ����"+to_chinese(str[0])+"��!\n"NOR);
     	return;
     }
   s=random(s);
   userskills[str[s]]+=1;
   tell_object(ob,HIR"��õ���һ����"+to_chinese(str[s])+"��!\n"NOR);     
   return ;
}

int setguaiskill(int chooseguai,int level,object guai)
{  
   set_std_skills(level,guai);
   switch (chooseguai)
    {
      case 1:set_moon_guai(level,guai);carry_moon_weapon();break;
      case 2:set_fangcun_guai(level,guai);carry_fangcun_weapon();break;
      case 3:set_putuo_guai(level,guai);carry_putuo_weapon();break;
      case 4:set_hell_guai(level,guai);carry_hell_weapon();break;
      case 5:set_longgong_guai(level,guai);carry_longgong_weapon();break;
      case 6:set_xueshan_guai(level,guai);carry_xueshan_weapon();break;
      default:set_wudidong_guai(level,guai);carry_wudidong_weapon();break;
    }
}
//����ôҲ������?
void heart_beat()
{
   object player;
   int kee,effkee,maxkee;
   maxkee=(int)this_object()->query_temp("maxkee");   
   effkee=(int)this_object()->query("eff_kee");
   kee=query("kee");
   if (effkee<maxkee) command("exert heal");
   if (kee<(int)(effkee*2/3)) command("exert recover");
   player=this_object()->query_temp("player");
   if (player && player->is_ghost())
     {
       message_vision(MAG"$N���ߣ�����Ц��һ��,һת���Ͳ�����!\n"NOR,me);
       destruct (me);
       return ;
     }
     	
   if (player)
    {
     if (player->query("kee")<1 || player->query("sen")<1 )
       {
        if (!this_object()->query("is_checking"))
         {  
          call_out("check_if_unconcious",2,player,this_object());
          this_object()->set("is_checking",1);
          return ;
         }
        else return; 
       }       
    
    }
   ::heart_beat();   
   return ;
}
void check_if_unconcious(object who,object me)
{
   if (!living(who))
     {
       if (present(who,environment(me)))
        {
         message_vision(MAG"$N���ߣ�����Ц��һ��,һת���Ͳ�����!\n"NOR,me);
         destruct (me);
         return ;
        }
     }
   else 
     {
       me->set_temp("is_checking",0);
     }
    return ;
}      
        

int check_time()
{
   if (!query_temp("appear")) 
     {
       set_temp("appear",1);
       call_out("check_time",300);
       return 1;
     }
   if (me->is_fighting()) 
     {
       call_out("check_time",300);
       return 1;
     }
   remove_call_out("check_time");
   message_vision(MAG"$N���˼��ܣ�����һ��������ʧ�ˡ�\n"NOR,
          this_object());
   destruct (this_object());
}


void die ()
{
    int pot,exp,i;
    object killerob,me;
    mixed questob;
    me=this_object();
    killerob=me->query_temp("last_damage_from");                
    questob=(object)me->query_temp("player"); 
    if (!questob ||!interactive(questob)||!living(questob)) 
       {
       	 message_vision("$N�ҽ�һ�������ˡ�\n",me);
       	 destruct (me);
       	 return;
       }	 
    questob->set_temp("kill",0); 
    if (!killerob) 
    {   
        message_vision("$N�ҽ�һ�������ˡ�\n",this_object());
        tell_object(questob,HIY"��õ������Ǳ�ܺ������У�\n"NOR);
        destruct(me);
        return;    
    }
    else if (killertemp)
     {
        if (killertemp!=questob )
         {
         if (!killertemp->query_leader())
          {
             message_vision("$N�ҽ�һ�������ˡ�\n",this_object());
             tell_object(questob,HIY"��õ������Ǳ�ܺ������У�\n"NOR);
             destruct(me);
             return;    
           
          }
         else if ( (killertemp->query_leader()) ->query("id")!=questob->query("id"))
          {
             message_vision("$N�ҽ�һ�������ˡ�\n",this_object());
             tell_object(questob,HIY"��õ������Ǳ�ܺ������У�\n"NOR);
             destruct(me);
             return;    
           
          }
         }
          
     } 
    if (killerob->query("id")!=questob->query("id"))
     {
      if (!killerob->query_leader())
       {  
         message_vision("$N�ҽ�һ�������ˡ�\n",this_object());
         tell_object(questob,HIY"��õ������Ǳ�ܺ������У�\n"NOR);
         destruct(me);
         return; 
       }
      else if ( (killerob->query_leader()) ->query("id") !=questob->query("id"))
          {
             message_vision("$N�ҽ�һ�������ˡ�\n",this_object());
             tell_object(questob,HIY"��õ������Ǳ�ܺ������У�\n"NOR);
             destruct(me);
             return;    
           
          } 
      }    
       
    switch(random(4))
     {
       case 1: message_vision("$N�ҽ�һ�������ˡ�\n",this_object());break;
       case 2: message_vision("$N�ȵ����������һ���������ȥ�ɣ�\n"
               +"$n�ۼ����Σ�ֻ�û��ɹ����̸�����$N�����С�\n",
               questob,this_object());break;
       case 3:message_vision("$N�ȵ����������һ���������ȥ�ɣ�\n"
               +"$n�޿��κΣ�����һ����⣬ֱ������ȥ�ˣ�������\n",
               questob,this_object());break;
       default :message_vision("$N�ȵ����������һ���������ȥ�ɣ�\n"
               +"$n�ԹԵķ���$N�Ľ���һ��Ҳ�����ˡ�\n",questob,this_object());
     }

    pot=me->query_temp("killrewardpot")*2;
    exp=me->query_temp("killrewardexp")*3;
    questob->add("potential",pot);
    questob->add("combat_exp",exp);
    questob->add_temp("continue_kill_guai",1);
    tell_object(questob,HIW"��õ���"+chinese_number(pot)+"��Ǳ�ܺ�"+
       CHINESE_D->chinese_number(exp)+"����С�\n"NOR);
    i=questob->query("kar");
    i=random(i);
    if (i>4 && questob->query_temp("turn")==12) rewardskill(questob);
    destruct(me);
   
}
//�����ñ��˰�æ���ι�   
void unconcious()
{
  killertemp=query_temp("last_damage_from");
  ::unconcious();
}
void init()
{
    if (is_busy()) return;
    add_action("do_follow","follow");
    username=query_temp("killername");
    if ((int)environment(me)->query("no_fight")) return; 
    if (random(10)>5)  
      {
      set_temp("firstsee",1);
       ::init();
       return ;
      }
       
    else 
    {
     if (this_player()->query("id")==username)
       { 
         if (!query_temp("firstsee"))
           {       
           if (random(10)>5)	
             message_vision(HIR"$N����$n����ֱ����ˮ!\n"NOR
             ,this_object(),this_player());
           else 
             message_vision(HIR"$Nһ������,�˷ܵĽе�:����!������������!\n"NOR
             ,this_object(),this_player());
           set_temp("firstsee",1);
           command("follow "+this_player()->query("id"));
           this_object()->kill_ob(this_player());  
           }
         else ::init(); 
         set_heart_beat(1);
          
        }
      ::init();    
     set_temp("firstsee",1);
     }
  
}

int do_follow(string arg)
{
    mapping exits;
    string *dirs;
    int size;
    object env=environment(this_player());
    object me=this_object();
    
    if (arg==me->query("id")&& present(arg,env))
      {
        if (env->query("no_fight"))
         {
           exits=env->query("exits");      
           dirs=keys(exits);
           size=sizeof(dirs);
           if (size>0)
             { 
//              this_player()->command("follow "+this_object()->query("id"));  
              call_out("leave_here",1,dirs[random(size-1)]);
          
             }
             
          }
//        this_player()->command("follow "+this_object()->query("id"));  
       }
     return 0;
}

int leave_here(string arg)
{
   command("go "+arg);
   return 1;
}  
