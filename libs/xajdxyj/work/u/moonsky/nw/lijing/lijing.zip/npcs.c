//"/u/oldcat/lijing/npcskill.h"
//piao 3/19/2000

#include <ansi.h>
inherit NPC;


string *stdskillclass=({"unarmed","dodge","force","spells"});

string *moonskillclass=({"baihua-zhang","moondance",
                   "moonforce","moonshentong"});    

string *fangcunskillclass=({"puti-zhi","jindouyun",
                   "wuxiangforce","dao"});

string *putuoskillclass=({"jienan-zhi","lotusmove",
                   "lotusforce","buddhism"});

string *hellskillclass=({"jinghun-zhang","ghost-steps",
                   "tonsillit","gouhunshu"});

string *longgongskillclass=({"dragonfight","dragonstep",
                   "dragonforce","seashentong"});

string *xueshanskillclass=({"cuixin-zhang","xiaoyaoyou",
                   "ningxie-force","dengxian-dafa"});

string *wudidongskillclass=({"yinfeng-zhua","lingfu-steps",
                   "huntian-qigong","yaofa"});
                   
string *wuzhuangskillclass=({"wuxing-quan","baguazhen",
                           "zhenyuan-force","taiyi"});

string *jjfskillclass=({"changquan","yanxing-steps",
                         "lengquan-force","baguazhou"});


string *fireskillclass=({"moyun-shou","moshenbu",
                         "moshen-force","moyunshentong"});

int set_std_skills (int level,object ob)
{
   ob->set_skill("unarmed",level);
   ob->set_skill("dodge",level);
   ob->set_skill("parry",level);
   ob->set_sklll("spells",level);
   ob->set_skill("force",level);
}

int set_guai_skills (int level,object ob,string *str)
{
   int i;
   for (i=0;i<4;i++)
    {
      ob->set_skill(str[i],level);
      ob->map_skill(stdskillclass[i],str[i]);
    }       
} 
int set_moon_guai (int level,object ob)
{  
   set_guai_skills(level,ob,moonskillclass);
   ob->set("family/family_name","�¹�");
   ob->set("gender","Ů��");
   ob->set_skill("sword",level);
   ob->set_skill("snowsword",level);
   ob->map_skill("sword","snowsword");
   ob->set("chat_msg_combat", ({
     (: cast_spell, "arrow" :),
     (: cast_spell, "mihun" :),
   }) );

}
int carry_moon_weapon()
{
   carry_object("/d/obj/weapon/sword/qingfeng")->wield();
   carry_object("/d/obj/armor/shoupi")->wear();
}

int set_fangcun_guai(int level,object ob)
{  
   set_guai_skills(level,ob,fangcunskillclass);
   ob->set("family/family_name","����ɽ���Ƕ�");
   ob->set_skill("stick",level);
   ob->set_skill("qianjun-bang",level);
   ob->map_skill("stick","qianjun-bang");
   ob->set("chat_msg_combat", ({
     (: cast_spell, "light" :),
     (: cast_spell, "dingshen":),
    (: perform_action,"stick","pili" :),
    (: perform_action,"stick","qiankun" :),
   }) );

}
int carry_fangcun_weapon()
{
   carry_object("/d/obj/weapon/stick/xiangmo")->wield();
   carry_object("/d/obj/armor/shoupi")->wear();
}

int set_putuo_guai(int level,object ob)
{
   set_guai_skills(level,ob,putuoskillclass);
   ob->set("family/family_name","�Ϻ�����ɽ");
   ob->set_skill("staff",level);
   ob->set_skill("lunhui-zhang",level);
   ob->map_skill("staff","lunhui-zhang");
   ob->set("chat_msg_combat", ({
     (: cast_spell, "bighammer" :),
   }) );

}
int carry_putuo_weapon()
{  
   carry_object("/d/obj/weapon/staff/budd_staff")->wield();
   carry_object("/d/obj/armor/shoupi")->wear();
}

int set_hell_guai(int level,object ob)
{
   set_guai_skills(level,ob,hellskillclass);
   ob->set("family/family_name","���޵ظ�");
   ob->set_skill("whip",level);
   ob->set_skill("kusang-bang",level);
   ob->set_skill("hellfire-whip",level);
   ob->map_skill("whip","hellfire-whip");
   ob->set("chat_msg_combat", ({
     (: cast_spell, "gouhun" :),
     (: exert_function, "powerup" :),
     (: perform_action,"whip","three" :),
   }) );

}
int carry_hell_weapon()
{  
   carry_object("/d/obj/weapon/whip/longsuo")->wield();
   carry_object("/d/obj/armor/shoupi")->wear();
}

int set_longgong_guai(int level,object ob)
{
   set_guai_skills(level,ob,longgongskillclass);
   ob->set("family/family_name","��������");
   ob->set_skill("hammer",level);
   ob->set_skill("huntian-hammer",level);
   ob->map_skill("hammer","huntian-hammer");
   ob->set("chat_msg_combat", ({
     (: cast_spell, "freez" :),
     (: exert_function,"roar":),
   }) );

}
int carry_longgong_weapon()
{
   carry_object("/d/sea/obj/meihuahammer")->wield();
   carry_object("/d/obj/armor/shoupi")->wear();
}

int set_xueshan_guai(int level,object ob)
{
   set_guai_skills(level,ob,xueshanskillclass);
   ob->set("family/family_name","��ѩɽ");
   ob->set_skill("blade",level);
   ob->set_skill("bingpo-blade",level);
   ob->map_skill("blade","bingpo-blade",level);
   ob->set("chat_msg_combat", ({
     (: cast_spell, "tuntian" :),
   }) );
}
int carry_xueshan_weapon()
{
   carry_object("/d/obj/weapon/blade/jindao")->wield();
   carry_object("/d/obj/armor/shoupi")->wear();
}

int set_wudidong_guai(int level,object ob)
{
    set_guai_skills(level,ob,wudidongskillclass);
    ob->set("family/family_name","�ݿ�ɽ�޵׶�");
    ob->set_skill("blade",level);
    ob->set_skill("kugu-blade",level);
    ob->map_skill("blade","kugu-blade");
    ob->set("chat_msg_combat", ({
     (: cast_spell, "bighammer" :),
   }) );

}
int carry_wudidong_weapon()
{   
    carry_object("/d/obj/weapon/blade/jindao")->wield();
    carry_object("/d/obj/armor/shoupi")->wear();
}

int set_wuzhuang_guai(int level,object ob)
{
    set_guai_skills(level,ob,wuzhuangskillclass);
    ob->set("family/family_name","��ׯ��");
    ob->set_skill("sword",level);
    ob->set_skill("sanqing-jian",level);
    ob->map_skill("sword","sanqing-jian");
    ob->set("chat_msg_combat", ({
     (: cast_spell, "zhenhuo" :),
   }) );
}

int carry_wuzhuang_weapon()
{
     carry_object("/d/obj/weapon/sword/qingfeng.c")->wield();
    carry_object("/d/obj/armor/shoupi")->wear();
}

int set_jjf_guai(int level,object ob)
{
    set_guai_skills(level,ob,jjfskillclass);
    ob->set("family/family_name","������");
    ob->set_skill("axe",level);
    ob->set_skill("sanban-axe",level);
    ob->map_skill("axe","sanban-axe");
    ob->set("chat_msg_combat", ({
   (: exert_function,"jingxin":),
   (: exert_function,"recover":),
     (: perform_action, "axe","sanban" :),
    }));
}

int carry_jjf_weapon()
{
    carry_object("/d/obj/armor/shoupi")->wear();
   carry_object("/d/obj/weapon/axe/huafu.c")->wield();

}

int set_fire_guai(int level,object ob)
{
    set_guai_skills(level,ob,fireskillclass);
    ob->set("family/family_name","���ƶ�");
    ob->set_skill("spear",level);
    ob->set_skill("huoyun-qiang",level);
    ob->map_skill("spear","huoyun-qiang");
    ob->set("chat_msg_combat", ({
     (: cast_spell, "sanmei" :),
     (: exert_function, "thunder" :),
   }) );
}

int carry_fire_weapon()
{
    carry_object("/d/obj/armor/shoupi")->wear();
   carry_object("/d/nanhai/obj/huojianqiang")->wield();
}
