//"/u/oldcat/lijing/npcskill.h"
//piao 3/19/2000

#include <ansi.h>
inherit NPC;


string *stdskillclass=({"unarmed","dodge","force","spells"});

string *moonskillclass=({"baihua-zhang","moondance",
                   "moonforce","moonshentong"});    

string *fangcunskillclass=({"puti-zhi","jindouyun",
                   "wuxiangforce","dao"});

string *putuoskillclass=({"jienan-zhi","lotusmove",
                   "lotusforce","buddhism"});

string *hellskillclass=({"jinghun-zhang","ghost-steps",
                   "tonsillit","gouhunshu"});

string *longgongskillclass=({"dragonfight","dragonstep",
                   "dragonforce","seashentong"});

string *xueshanskillclass=({"cuixin-zhang","xiaoyaoyou",
                   "ningxie-force","dengxian-dafa"});

string *wudidongskillclass=({"yinfeng-zhua","lingfu-steps",
                   "huntian-qigong","yaofa"});
                   
//jjf                    



int set_std_skills (int level,object ob)
{
   ob->set_skill("unarmed",level);
   ob->set_skill("dodge",level);
   ob->set_skill("parry",level);
   ob->set_sklll("spells",level);
   ob->set_skill("force",level);
}

int set_guai_skills (int level,object ob,string *str)
{
   int i;
   for (i=0;i<4;i++)
    {
      ob->set_skill(str[i],level);
      ob->map_skill(stdskillclass[i],str[i]);
    }       
} 
int set_moon_guai (int level,object ob)
{  
   set_guai_skills(level,ob,moonskillclass);
   ob->set("family/family_name","�¹�");
   ob->set("gender","Ů��");
   ob->set_skill("sword",level);
   ob->set_skill("snowsword",level);
   ob->map_skill("sword","snowsword");
   ob->set("chat_msg_combat", ({
     (: cast_spell, "arrow" :),
     (: cast_spell, "mihun" :),
   }) );

}
int carry_moon_weapon()
{
   carry_object("/d/obj/weapon/sword/qingfeng")->wield();
   carry_object("/d/obj/armor/shoupi")->wear();
}

int set_fangcun_guai(int level,object ob)
{  
   set_guai_skills(level,ob,fangcunskillclass);
   ob->set("family/family_name","����ɽ���Ƕ�");
   ob->set_skill("stick",level);
   ob->set_skill("qianjun-bang",level);
   ob->map_skill("stick","qianjun-bang");
   ob->set("chat_msg_combat", ({
     (: cast_spell, "light" :),
     (: cast_spell, "dingshen":),
   }) );

}
int carry_fangcun_weapon()
{
   carry_object("/d/obj/weapon/stick/xiangmo")->wield();
   carry_object("/d/obj/armor/shoupi")->wear();
}

int set_putuo_guai(int level,object ob)
{
   set_guai_skills(level,ob,putuoskillclass);
   ob->set("family/family_name","�Ϻ�����ɽ");
   ob->set_skill("staff",level);
   ob->set_skill("lunhui-zhang",level);
   ob->map_skill("staff","lunhui-zhang");
   ob->set("chat_msg_combat", ({
     (: cast_spell, "bighammer" :),
   }) );

}
int carry_putuo_weapon()
{  
   carry_object("/d/obj/weapon/staff/budd_staff")->wield();
   carry_object("/d/obj/armor/shoupi")->wear();
}

int set_hell_guai(int level,object ob)
{
   set_guai_skills(level,ob,hellskillclass);
   ob->set("family/family_name","���޵ظ�");
   ob->set_skill("whip",level);
   ob->set_skill("hellfire-whip",level);
   ob->map_skill("whip","hellfire-whip");
   ob->set("chat_msg_combat", ({
     (: cast_spell, "gouhun" :),
   }) );

}
int carry_hell_weapon()
{  
   carry_object("/d/obj/weapon/whip/longsuo")->wield();
   carry_object("/d/obj/armor/shoupi")->wear();
}

int set_longgong_guai(int level,object ob)
{
   set_guai_skills(level,ob,longgongskillclass);
   ob->set("family/family_name","��������");
   ob->set_skill("hammer",level);
   ob->set_skill("huntian-hammer",level);
   ob->map_skill("hammer","huntian-hammer");
   ob->set("chat_msg_combat", ({
     (: cast_spell, "freez" :),
   }) );

}
int carry_longgong_weapon()
{
   carry_object("/d/sea/obj/meihuahammer")->wield();
   carry_object("/d/obj/armor/shoupi")->wear();
}

int set_xueshan_guai(int level,object ob)
{
   set_guai_skills(level,ob,xueshanskillclass);
   ob->set("family/family_name","��ѩɽ");
   ob->set_skill("blade",level);
   ob->set_skill("bingpo-blade",level);
   ob->map_skill("blade","bingpo-blade",level);
}
int carry_xueshan_weapon()
{
   carry_object("/d/obj/weapon/blade/jindao")->wield();
   carry_object("/d/obj/armor/shoupi")->wear();
}

int set_wudidong_guai(int level,object ob)
{
    set_guai_skills(level,ob,wudidongskillclass);
    ob->set("family/family_name","�ݿ�ɽ�޵׶�");
    ob->set_skill("blade",level);
    ob->set_skill("kugu-blade",level);
    ob->map_skill("blade","kugu-blade");
    ob->set("chat_msg_combat", ({
     (: cast_spell, "bighammer" :),
   }) );

}
int carry_wudidong_weapon()
{   
    carry_object("/d/obj/weapon/blade/jindao")->wield();
    carry_object("/d/obj/armor/shoupi")->wear();
}