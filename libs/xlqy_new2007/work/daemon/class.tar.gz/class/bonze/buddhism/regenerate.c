// by gamer
#include <ansi.h>

inherit F_CLEAN_UP;

void remove_effect(object me, int amount,int effect);

int cast(object me, object target)
{
	int skill,effect;
	string level;
	me=this_player();
	if( !target ) target = me;

	if( (int)me->query_skill("buddhism", 1) < 100 )
		return notify_fail("��Ĵ�˷���Ϊ���㡣\n");
	if(me->query("family/family_name")!="�Ϻ�����ɽ")
                return notify_fail("���Ƿ��ŵ��Ӳ����á�ԡ����������\n");
        if( (int)me->query("mana") < 1000 )     
                return notify_fail("��ķ���������\n");
	if( (int)me->query("kee") < 300 )
		return notify_fail("�����Ѫ���㡣\n");
	if( (int)me->query("sen") < 300 )
		return notify_fail("��ľ����㡣\n");
        if( (int)target->query_temp("in_regenerate") ) 
        {
              	tell_object(me,target->name()+"�Ѿ��ܵ�������������!\n");
              	  return 1;
         }

        skill = me->query_skill("spells");
	
	
        me->add("mana", -800);
        me->receive_damage("kee", 30);
	me->receive_damage("sen", 30);

        message_vision(HIY"$NĬ���������һ�������������$n��ԡ�������������С�\n" NOR, me,target);
	if(target != me)
		skill = skill/2+random(skill/2);
if(me->query_temp("putuo_set")) skill += skill/2;
        target->set_temp("in_regenerate", 1);
      
        level = me->query("skill_level/spells");
        effect = 1;
	if(level == "expert")
	{
		target->add_temp("apply/regenerate_kee",skill/3);
		target->add_temp("apply/regenerate_sen",skill/3);	
		 effect = 2;
	}
	else if(level == "master")
	{
		target->add_temp("apply/regenerate_kee",skill/3);
		target->add_temp("apply/regenerate_sen",skill/3);	
		target->add_temp("apply/regenerate_mana",skill/5);
		 effect = 3;	
	}
	
	else if(level == "grandmaster")
	{
		target->add_temp("apply/regenerate_kee",skill/3);
		target->add_temp("apply/regenerate_sen",skill/3);	
		target->add_temp("apply/regenerate_mana",skill/5);	
		target->add_temp("apply/regenerate_force",skill/5);
		 effect = 4;	
	}
	else target->add_temp("apply/regenerate_kee",skill/3);
	
    //    me->start_call_out( (: call_other, __FILE__, "remove_effect", target, skill,effect :), skill);
	call_out("remove_effect",skill, target, skill,effect);
        if( me->is_fighting() ) me->start_busy(3);

        return 5+random(5);
}

void remove_effect(object me, int amount,int effect)
{
	if(!me) return;
        me->delete_temp("in_regenerate");
        if(effect == 4)
      	    me->add_temp("apply/regenerate_force",-amount/5);
      	if(effect > 2)
      		 me->add_temp("apply/regenerate_mana",-amount/5);
      	if(effect > 1)
      		me->add_temp("apply/regenerate_sen",-amount/3);
       
        me->add_temp("apply/regenerate_kee",-amount/3);
         
        tell_object(me, "������ԡ��ʥ����ʧ��!\n");
	return;
}


