// by gamer
#include <ansi.h>

inherit F_CLEAN_UP;

void remove_effect(object me, int amount,int effect);

int cast(object me, object target)
{
	int skill,effect;
	string level;
	me=this_player();
	if( !target ) target = me;

	if( (int)me->query_skill("dao", 1) < 150 )
		return notify_fail("��ĵ�����Ϊ���㡣\n");
	if(me->query("family/family_name")!="����ɽ���Ƕ�")
                return notify_fail("���Ƿ�����Ӳ����á����ǻ��꡹��\n");
        if( (int)me->query("mana") < 1000 )     
                return notify_fail("��ķ���������\n");
	if( (int)me->query("kee") < 300 )
		return notify_fail("�����Ѫ���㡣\n");
	if( (int)me->query("sen") < 300 )
		return notify_fail("��ľ����㡣\n");
        if( (int)target->query_temp("in_preservation") ) 
        {
              	tell_object(me,target->name()+"�Ѿ���ֱ������Լ��Ļ�����!\n");
              	  return 1;
         }

        skill = me->query_skill("spells");
if(me->query_temp("fc_set")) skill += skill/2;
	
	
        me->add("mana", -800);
        me->receive_damage("kee", 30);
	me->receive_damage("sen", 30);
	
        message_vision(HIG"$N���������дʣ�ʩչ������ͨ��$n�Ļ������ι������ڡ�\n" NOR, me,target);
	if(target != me)
		skill = skill/2;
        target->set_temp("in_preservation", 1);
      
        level = me->query("skill_level/spells");
        effect = 1;
	if(level == "expert")
	{
		target->add_temp("apply/preservation_kee",skill*2/3);
		target->add_temp("apply/preservation_sen",skill/2);		
		 effect = 2;
	}
	else if(level == "master")
	{
		target->add_temp("apply/regenerate_kee",skill);
		target->add_temp("apply/preservation_sen",skill*2/3);	
		
		 effect = 3;	
	}
	
	else if(level == "grandmaster")
	{
		target->add_temp("apply/preservation_kee",skill*3/2);
		target->add_temp("apply/preservation_sen",skill);	
		
		 effect = 4;	
	}
	else 	target->add_temp("apply/preservation_kee",skill/2);
		
	
        target->start_call_out( (: call_other, __FILE__, "remove_effect", target, skill,effect :), skill);

        if( me->is_fighting() ) me->start_busy(3);

        return 5+random(5);
}

void remove_effect(object me, int amount,int effect)
{
        me->delete_temp("in_preservation");
        if(effect == 4)
      	 {   me->add_temp("apply/preservation_kee",-amount*3/2);
      	     me->add_temp("apply/preservation_sen",-amount);
      	}
      	else if(effect == 3)
      	{   me->add_temp("apply/preservation_kee",-amount);
      	     me->add_temp("apply/preservation_sen",-amount*2/3);
      	}
      	else if(effect == 2)
      	{   me->add_temp("apply/preservation_kee",-amount*2/3);
      	     me->add_temp("apply/preservation_sen",-amount/2);
      	}
       else me->add_temp("apply/preservation_kee",-amount/2);
         
        tell_object(me, "����ǻ����Ч����ʧ��!\n");
	return;
}


