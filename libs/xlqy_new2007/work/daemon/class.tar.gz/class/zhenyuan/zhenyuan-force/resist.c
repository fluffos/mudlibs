// by gamer
#include <ansi.h>

inherit F_CLEAN_UP;


void remove_resist(object me,int skill,int effect);

int exert(object me, object target)
{
	int skill,effect,atk;
	int i;
	string level;
	me=this_player();
	if( !target ) target = me;

	
	if( (int)me->query_skill("zhenyuan-force", 1) < 120 )
		return notify_fail("�����Ԫ����Ϊ���㡣\n");
	if(me->query("family/family_name")!="��ׯ��")
                return notify_fail("��ǵ���֮��ĵ��ӣ����ﶮ�������������֮���\n");
        if( (int)me->query("force") < 1000 )     
                return notify_fail("�������������\n");
	if( (int)me->query("kee") < 300 )
		return notify_fail("�����Ѫ���㡣\n");
	if( (int)me->query("sen") < 300 )
		return notify_fail("��ľ����㡣\n");
        if( (int)target->query_temp("in_resist_wuxing") ) 
        {
              	tell_object(me,target->name()+"�Ѿ��ܵ����ֿ����С���Ӱ����!\n");
              	  return 1;
         }
         message_vision(HIG"$N������Ԫ�񹦣�����������������һ��һ����̫��Բת��һ����Ȼ�沪�ľ���˲����$n��תһ���졣\n" NOR, me,target); 
	 tell_object(target,HIW"�����һ�������ȣ�ȫ������������������������ӿȪ����֫�ٺ��޲���̹���̲�ס������Х��\n" NOR); 
	
		skill = me->query_skill("force");
		me->add("force", -360);
	        me->receive_damage("kee", 120);
		me->receive_damage("sen", 120);
   	 target->set_temp("in_resist_wuxing",1);
	        level = me->query("skill_level/force");
	       effect = 1;
	       skill = skill*2/3+random(skill/2);
	       if(target !=me)
	       	skill = skill/2+random(skill/2);
if(me->query_temp("wzg_set")) skill += skill/2;
	       
		if(level == "expert")
		{
			i = random(6);
			if(i == 0)
			{	target->add_temp("apply/sub_huo",skill/10);	
				target->add_temp("apply/sub_max_huo",skill);	
				target->add_temp("apply/sub_jin",skill/10);	
				target->add_temp("apply/sub_max_jin",skill);
				effect = 5;
			}
			else if(i == 1)
			{	target->add_temp("apply/sub_huo",skill/10);	
				target->add_temp("apply/sub_max_huo",skill);	
				target->add_temp("apply/sub_mu",skill/10);	
				target->add_temp("apply/sub_max_mu",skill);	
				effect = 6;
			}
			else if(i == 2)
			{	target->add_temp("apply/sub_huo",skill/10);	
				target->add_temp("apply/sub_max_huo",skill);	
				target->add_temp("apply/sub_shui",skill/10);	
				target->add_temp("apply/sub_max_shui",skill);		
				effect = 7;
			}
			else if(i == 3)
			{
				target->add_temp("apply/sub_jin",skill/10);	
				target->add_temp("apply/sub_max_jin",skill);
				target->add_temp("apply/sub_shui",skill/10);	
				target->add_temp("apply/sub_max_shui",skill);	
				effect = 8;
			}
			else if(i == 4)
			{
				target->add_temp("apply/sub_mu",skill/10);	
				target->add_temp("apply/sub_max_mu",skill);
				target->add_temp("apply/sub_shui",skill/10);	
				target->add_temp("apply/sub_max_shui",skill);	
				effect = 9;
			}
			else 
			{
				target->add_temp("apply/sub_mu",skill/10);	
				target->add_temp("apply/sub_max_mu",skill);
				target->add_temp("apply/sub_jin",skill/10);	
				target->add_temp("apply/sub_max_jin",skill);
				effect = 10;
			}
			
		}
		else if(level == "master")
		{
			i = random(4);
			if(i == 0)
			{	target->add_temp("apply/sub_huo",skill/8);	
				target->add_temp("apply/sub_max_huo",skill*3/2);	
				target->add_temp("apply/sub_jin",skill/8);	
				target->add_temp("apply/sub_max_jin",skill*3/2);	
				target->add_temp("apply/sub_mu",skill/8);	
				target->add_temp("apply/sub_max_mu",skill*3/2);
				effect = 11;
			}
			else if(i == 1)
			{	target->add_temp("apply/sub_huo",skill/8);	
				target->add_temp("apply/sub_max_huo",skill*3/2);
				target->add_temp("apply/sub_jin",skill/8);	
				target->add_temp("apply/sub_max_jin",skill*3/2);	
				target->add_temp("apply/sub_shui",skill/8);	
				target->add_temp("apply/sub_max_shui",skill*3/2);	
				effect = 12;
			}
			else if(i == 2)
			{	target->add_temp("apply/sub_jin",skill/8);	
				target->add_temp("apply/sub_max_jin",skill*3/2);	
				target->add_temp("apply/sub_mu",skill/8);	
				target->add_temp("apply/sub_max_mu",skill*3/2);	
				target->add_temp("apply/sub_shui",skill/8);	
				target->add_temp("apply/sub_max_shui",skill*3/2);
				effect = 13;	
			}
			else 
			{	target->add_temp("apply/sub_shui",skill/8);	
				target->add_temp("apply/sub_max_shui",skill*3/2);	
				target->add_temp("apply/sub_huo",skill/8);	
				target->add_temp("apply/sub_max_huo",skill*3/2);
				target->add_temp("apply/sub_mu",skill/8);	
				target->add_temp("apply/sub_max_mu",skill*3/2);
				effect = 14;
			}
			
		}
		
		else if(level == "grandmaster")
		{
				target->add_temp("apply/sub_jin",skill/6);	
				target->add_temp("apply/sub_max_jin",skill*2);	
				target->add_temp("apply/sub_shui",skill/6);	
				target->add_temp("apply/sub_max_shui",skill*2);	
				target->add_temp("apply/sub_huo",skill/6);	
				target->add_temp("apply/sub_max_huo",skill*2);
				target->add_temp("apply/sub_mu",skill/6);	
				target->add_temp("apply/sub_max_mu",skill*2);
			 effect = 15;	
		}
		else {
			i = random(4);
			if(i == 0)
			{	target->add_temp("apply/sub_huo",skill/12);	
				target->add_temp("apply/sub_max_huo",skill/2);	
				effect = 1;
			}
			else if(i == 1)
			{	target->add_temp("apply/sub_jin",skill/12);	
				target->add_temp("apply/sub_max_jin",skill/2);	
				effect = 2;
			}
			else if(i == 2)
			{	target->add_temp("apply/sub_mu",skill/12);	
				target->add_temp("apply/sub_max_mu",skill/2);	
				effect = 3;
			}
			else 
			{	target->add_temp("apply/sub_shui",skill/12);	
				target->add_temp("apply/sub_max_shui",skill/2);	
				effect = 4;
			}
		
		     }
		
	        target->start_call_out( (: call_other, __FILE__, "remove_resist", target,skill, effect :), skill);
	
			
		if(me->is_fighting()) me->start_busy(3);	
	
        return 1;
}

void remove_resist(object target,int skill,int effect)
{
	if(!target) return;
	 target->delete_temp("in_resist_wuxing");
	  tell_object(target, "�����ܵ��ġ��ֿ����С�Ч����ʧ��!\n");
	switch(effect)
	{
		case 1:
				target->add_temp("apply/sub_huo",-skill/12);	
				target->add_temp("apply/sub_max_huo",-skill/2);	
		
		break;
		case 2:
				target->add_temp("apply/sub_jin",-skill/12);	
				target->add_temp("apply/sub_max_jin",-skill/2);		
		
		break;
		case 3:
		target->add_temp("apply/sub_mu",-skill/12);	
				target->add_temp("apply/sub_max_mu",-skill/2);	
		
		break;
		case 4:
		target->add_temp("apply/sub_shui",-skill/12);	
				target->add_temp("apply/sub_max_shui",-skill/2);	
		
		break;
		case 5:
		target->add_temp("apply/sub_huo",-skill/10);	
				target->add_temp("apply/sub_max_huo",-skill);	
				target->add_temp("apply/sub_jin",-skill/10);	
				target->add_temp("apply/sub_max_jin",-skill);
		
		break;
		case 6:
		target->add_temp("apply/sub_huo",-skill/10);	
				target->add_temp("apply/sub_max_huo",-skill);	
				target->add_temp("apply/sub_mu",-skill/10);	
				target->add_temp("apply/sub_max_mu",-skill);
		
		break;
		case 7:
		
		target->add_temp("apply/sub_huo",-skill/10);	
				target->add_temp("apply/sub_max_huo",-skill);	
				target->add_temp("apply/sub_shui",-skill/10);	
				target->add_temp("apply/sub_max_shui",-skill);	
		break;
		case 8:
		target->add_temp("apply/sub_jin",-skill/10);	
				target->add_temp("apply/sub_max_jin",-skill);
				target->add_temp("apply/sub_shui",-skill/10);	
				target->add_temp("apply/sub_max_shui",-skill);	
		
		break;
		case 9:
		target->add_temp("apply/sub_mu",-skill/10);	
				target->add_temp("apply/sub_max_mu",-skill);
				target->add_temp("apply/sub_shui",-skill/10);	
				target->add_temp("apply/sub_max_shui",-skill);	
		
		break;
		case 10:
		target->add_temp("apply/sub_mu",-skill/10);	
				target->add_temp("apply/sub_max_mu",-skill);
				target->add_temp("apply/sub_jin",-skill/10);	
				target->add_temp("apply/sub_max_jin",-skill);
		
		break;
		case 11:
		target->add_temp("apply/sub_huo",-skill/8);	
				target->add_temp("apply/sub_max_huo",-skill*3/2);	
				target->add_temp("apply/sub_jin",-skill/8);	
				target->add_temp("apply/sub_max_jin",-skill*3/2);	
				target->add_temp("apply/sub_mu",-skill/8);	
				target->add_temp("apply/sub_max_mu",-skill*3/2);
		
		break;
		case 12:
		target->add_temp("apply/sub_huo",-skill/8);	
				target->add_temp("apply/sub_max_huo",-skill*3/2);
				target->add_temp("apply/sub_jin",-skill/8);	
				target->add_temp("apply/sub_max_jin",-skill*3/2);	
				target->add_temp("apply/sub_shui",-skill/8);	
				target->add_temp("apply/sub_max_shui",-skill*3/2);
		
		break;
		case 13:
		target->add_temp("apply/sub_jin",-skill/8);	
				target->add_temp("apply/sub_max_jin",-skill*3/2);	
				target->add_temp("apply/sub_mu",-skill/8);	
				target->add_temp("apply/sub_max_mu",-skill*3/2);	
				target->add_temp("apply/sub_shui",-skill/8);	
				target->add_temp("apply/sub_max_shui",-skill*3/2);
		
		break;
		case 14:
		target->add_temp("apply/sub_shui",-skill/8);	
				target->add_temp("apply/sub_max_shui",-skill*3/2);	
				target->add_temp("apply/sub_huo",-skill/8);	
				target->add_temp("apply/sub_max_huo",-skill*3/2);
				target->add_temp("apply/sub_mu",-skill/8);	
				target->add_temp("apply/sub_max_mu",-skill*3/2);
		
		break;
		case 15:
		target->add_temp("apply/sub_jin",-skill/6);	
				target->add_temp("apply/sub_max_jin",-skill*2);	
				target->add_temp("apply/sub_shui",-skill/6);	
				target->add_temp("apply/sub_max_shui",-skill*2);	
				target->add_temp("apply/sub_huo",-skill/6);	
				target->add_temp("apply/sub_max_huo",-skill*2);
				target->add_temp("apply/sub_mu",-skill/6);	
				target->add_temp("apply/sub_max_mu",-skill*2);
		
		break;

		
	}
	
}


